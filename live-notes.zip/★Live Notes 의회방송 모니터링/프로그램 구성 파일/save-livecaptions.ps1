﻿# Live Notes (의회방송 모니터링): Windows 11 라이브 캡션(Win+Ctrl+L)의 자막을 텍스트 파일로 계속 저장
# 판: 2026.11.22-3 (최신본: https://github.com/jinyoung-plus/live-notes)
# 사용 방법: Live Notes 실행.bat 더블클릭 (라이브 캡션이 꺼져 있으면 자동으로 켭니다)
#   직접 실행: powershell -ExecutionPolicy Bypass -File .\save-livecaptions.ps1
# 종료: 보기 화면의 [프로그램 끝내기] 또는 Ctrl+C (마지막 문장까지 저장하고 끝납니다)
#
# 주요 기능: ① 위원장 진행 멘트를 알아듣고 위원별 구분선과 위원 이름 표시
#              ('자동저장노트' 폴더의 '위원명단.txt'로 잘못 인식된 이름을 가장 가까운 이름으로 보정)
#           ② 쪽수 언급(354페이지, 오백팔십쪽)과 '관심키워드.txt'의 단어를 강조하고, 키워드는 소리로 알림
#           ③ 너무 긴 줄은 읽기 좋은 길이로 나눔
#           ④ 구분선·쪽수·키워드만 모은 '목차' 파일을 함께 저장
#           ⑤ 문장부호 없이 길게 이어지는 발언은 자막 창에서 밀려나기 전에 앞부분부터 미리 저장
#           ⑥ 같은 구간 중복 저장 방지(금액·단위가 다르면 다른 문장으로 보고 둘 다 남김), 소수점 숫자 보존,
#              숫자·단위 붙여쓰기, 본문·목차 파일 쓰기 실패 시 각각 경고·재시도·복구 파일 저장
# 보기 화면: 실행하면 '받아쓰기보기.html'이 브라우저에 자동으로 열림(내 PC 전용 주소 http://127.0.0.1:8765)
#   [② 새 기록 시작]을 누를 때마다 새 파일(날짜_01, 02 …)로 저장, [받아쓰기 중지]·[재개]는 같은 파일에 이어 씀,
#   [종료하고 저장]으로 마무리, [프로그램 끝내기]는 실행 창과 자막 창까지 닫음
#   시작 순간 자막 창에 남아 있던 지난 자막은 건너뜀
#   왼쪽 유튜브 방송·오른쪽 받아쓰기, 설정, 사용 안내, [프로그램 끝내기]
#   보기 화면 왼쪽 아래 '실시간 자막' 칸에 지금 자막을 보여 주고, 라이브 캡션 창을 그 칸 위치·크기로 옮김
#   (자막 창 위치가 '화면에 오버레이 됨'일 때만 옮길 수 있음. 옮기지 못해도 받아쓰기는 그대로 됨)
#   자막 창이 준비되지 않았거나 자막이 영어로 나오면 보기 화면에 안내(받아쓰기 시작은 막지 않음)
#   위원명단·관심키워드는 실행 중에 바꿔도 몇 초 안에 다시 읽음
#   보기 화면을 띄우지 못하면 예전처럼 바로 저장을 시작함
# 종료 코드: 0 정상 저장, 1 복구 파일 확인 필요, 2 저장 실패, 3 이미 실행 중(보기 화면만 앞으로/다시 엶, 실행 창은 조용히 닫힘),
#            7 이미 실행 중인데 보기 화면 주소를 찾지 못함,
#            4 받아쓰기를 한 번도 시작하지 않고 끝냄, 5 보기 화면 [프로그램 끝내기]로 정상 종료(실행 창도 닫음)
#            6 받아쓰는 중 오류가 있었음(다시 시도하며 계속 저장했지만 일부가 빠졌을 수 있음)

param(
    [string]$OutFile = (Join-Path (Join-Path ([Environment]::GetFolderPath('Desktop')) '자동저장노트') ("{0:yyyyMMdd_HHmm}_자동저장노트.txt" -f (Get-Date))),
    [int]$IntervalMs = 1000,
    [int]$HoldTicks = 2,    # 방금 끝난 문장을 몇 번(약 몇 초) 더 지켜본 뒤 저장할지. 크게 하면 늦지만 더 안전
    [int]$MaxLineLength = 120,  # 한 줄 최대 글자 수(넘으면 다음 줄로 나눔)
    [switch]$ClockTime,     # 붙이면 경과 시간 대신 실제 시각(14:01:09)으로 기록
    [switch]$NoSound,       # 붙이면 키워드 알림 소리를 끔
    [string]$Replay,        # 점검용: 저장된 파일을 다시 읽어 정리
    [string]$Simulate,      # 점검용: 자막 화면 변화를 한 줄씩 적은 파일로 시험
    [string]$SettingsDir,   # 위원명단·관심키워드 파일을 둘 폴더 (기본: 바탕화면 '자동저장노트')
    [switch]$NoViewer,      # 붙이면 보기 화면을 띄우지 않음
    [switch]$NoBrowser,     # 붙이면 보기 화면 주소만 알려 주고 브라우저는 열지 않음
    [int]$ViewerPort = 8765, # 보기 화면 주소의 포트(이미 쓰이면 다음 번호로)
    [switch]$WaitStart,     # 점검용: -Simulate 에서도 [② 새 기록 시작]을 기다림
    [switch]$FromViewer     # 보기 화면의 [받아쓰기 프로그램 다시 켜기]로 켠 경우 (열려 있는 보기 화면을 그대로 씀)
)

$ScriptDir = $PSScriptRoot
if (-not $ScriptDir) { $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$utf8Bom = New-Object System.Text.UTF8Encoding($true)

# 위원명단·관심키워드는 받아쓰기 파일과 같은 바탕화면 '자동저장노트' 폴더에 둠
# (보기 화면 '받아쓰기보기.html'에서 이 폴더 하나만 연결하면 보기와 설정 입력이 모두 됨)
if (-not $SettingsDir) { $SettingsDir = Join-Path ([Environment]::GetFolderPath('Desktop')) '자동저장노트' }
if (-not (Test-Path -LiteralPath $SettingsDir)) { try { New-Item -ItemType Directory -Path $SettingsDir -Force | Out-Null } catch { } }
$RosterFile = Join-Path $SettingsDir '위원명단.txt'
$KeywordFile = Join-Path $SettingsDir '관심키워드.txt'
# 예전처럼 실행 파일 폴더에 설정 파일을 채워 두었다면 처음 한 번 옮겨 씀
foreach ($nm in @('위원명단.txt', '관심키워드.txt')) {
    $old = Join-Path $ScriptDir $nm; $new = Join-Path $SettingsDir $nm
    if ((Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $new) -and ($old -ne $new)) {
        try { Copy-Item -LiteralPath $old -Destination $new } catch { }
    }
}

# ───────────────────────── 설정 파일 읽기 ─────────────────────────

# 메모장에서 UTF-8 이든 ANSI(한글 완성형)든 상관없이 읽음
function Read-ListFile([string]$path, [switch]$Raw) {
    if (-not (Test-Path -LiteralPath $path)) { return @() }
    $bytes = [System.IO.File]::ReadAllBytes($path)
    try {
        $txt = (New-Object System.Text.UTF8Encoding($false, $true)).GetString($bytes)
    } catch {
        try { $txt = [System.Text.Encoding]::GetEncoding(949).GetString($bytes) } catch { $txt = [System.Text.Encoding]::Default.GetString($bytes) }
    }
    $txt = $txt.TrimStart([char]0xFEFF)
    if ($Raw) { return ($txt -split "`r?`n") }
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in ($txt -split "`r?`n")) {
        $l = $l.Trim()
        if ($l -eq '' -or $l.StartsWith('#')) { continue }
        $out.Add($l)
    }
    return $out.ToArray()
}

function New-TemplateFile([string]$path, [string]$content) {
    if (Test-Path -LiteralPath $path) { return }
    try { [System.IO.File]::WriteAllText($path, $content, $utf8Bom) } catch { }
}

New-TemplateFile $RosterFile @"
# 위원 명단 (한 줄에 한 사람, 이름만 적으면 됩니다)
# 자막에서 이름이 틀리게 나와도 이 명단에서 가장 비슷한 이름으로 바로잡아 표시합니다.
# 자주 틀리게 나오는 이름은 = 뒤에 쉼표로 적어 두면 더 정확합니다.
# 예)  홍길동
#      홍길순 = 홍길선, 홍기순
# '#'으로 시작하는 줄은 설명이라 무시됩니다. 아래에 위원 이름을 적고 저장하세요.

"@

New-TemplateFile $KeywordFile @"
# 관심 키워드 (한 줄에 하나)
# 부서명 등 주요 키워드를 적어 두면 그 말이 나올 때 강조하고 소리로 알려 줍니다.
# 띄어쓰기는 상관없습니다. (예: '늘봄 교실'과 '늘봄교실'을 같은 말로 봅니다)
# 예)  교육복지과
#      늘봄
#      무상급식
# '#'으로 시작하는 줄은 설명이라 무시됩니다. 아래에 키워드를 적고 저장하세요.

"@

# 위원 명단: 이름 → 그 이름과 별칭들
$Roster = New-Object System.Collections.Generic.List[object]
$Keywords = New-Object System.Collections.Generic.List[object]
$script:settingsStamp = ''

function Get-SettingsStamp {
    $st = ''
    foreach ($f in @($RosterFile, $KeywordFile)) {
        try { if (Test-Path -LiteralPath $f) { $st += [string](Get-Item -LiteralPath $f).LastWriteTimeUtc.Ticks } } catch { }
        $st += '|'
    }
    return $st
}

function Import-Settings {
    try {
        $r = @(Read-ListFile $RosterFile)
        $k = @(Read-ListFile $KeywordFile)
    } catch { return $false }    # 보기 화면에서 저장하는 중이면 다음에 다시 읽음
    $Roster.Clear(); $Keywords.Clear()
    foreach ($l in $r) {
        $name, $alias = $l -split '=', 2
        $name = ($name -replace '\s', '')
        if ($name -notmatch '^[가-힣]{2,5}$') { continue }
        $forms = New-Object System.Collections.Generic.List[string]
        $forms.Add($name)
        if ($alias) { foreach ($a in ($alias -split '[,，、]')) { $a = ($a -replace '\s', ''); if ($a) { $forms.Add($a) } } }
        $Roster.Add([pscustomobject]@{ Name = $name; Forms = $forms.ToArray() })
    }
    foreach ($l in $k) {
        $kk = ($l -replace '[\s?!,.]', '')
        if ($kk.Length -ge 2) { $Keywords.Add([pscustomobject]@{ Show = $l; Key = $kk }) }
    }
    $script:settingsStamp = Get-SettingsStamp
    return $true
}

# 실행 중에 보기 화면이나 메모장에서 설정을 고치면 몇 초 안에 다시 읽음
function Update-SettingsIfChanged {
    if ((Get-SettingsStamp) -eq $script:settingsStamp) { return }
    if (Import-Settings) {
        Write-Host ("[설정 반영] 위원 {0}명, 관심 키워드 {1}개를 다시 불러왔습니다." -f $Roster.Count, $Keywords.Count) -ForegroundColor Green
        Repair-MemberLabels
    }
}

# 이미 저장한 파일의 글 한 군데를 바꿈 (임시 파일에 다 쓴 뒤 한 번에 바꿔 끼우므로 도중에 꺼져도 원래 파일은 남음)
function Update-FileText([string]$f, [string]$old, [string]$new) {
    if (-not $f -or -not (Test-Path -LiteralPath $f)) { return $false }
    try {
        $txt = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
        if (-not $txt.Contains($old)) { return $false }
        $tmp = $f + '.tmp'
        try {
            [System.IO.File]::WriteAllText($tmp, $txt.Replace($old, $new), $utf8Bom)
            [System.IO.File]::Replace($tmp, $f, [NullString]::Value)
        } finally {
            if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
        }
        return $true
    } catch { return $false }
}

# 파일 내용을 통째로 바꿔 끼움 (임시 파일 → 교체, 보기 화면이 읽는 중이면 잠깐 뒤 다시 시도)
function Set-FileTextSafe([string]$f, [string]$text) {
    $tmp = $f + '.tmp'
    try {
        [System.IO.File]::WriteAllText($tmp, $text, $utf8Bom)
        for ($try = 1; $try -le 5; $try++) {
            try { [System.IO.File]::Replace($tmp, $f, [NullString]::Value); return $true }
            catch { if ($try -eq 5) { throw }; Start-Sleep -Milliseconds 150 }
        }
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
    return $false
}

# 보기 화면 [편집 모드]에서 고친 한 문장을 저장 파일(과 목차 파일)에 반영
#   $e.Old: 고치기 전 그 문장의 파일 줄들(긴 문장은 여러 줄), $e.Start: 그 첫 줄 위치, $e.Text: 고친 글(비우면 그 문장을 지움)
#   반환: ok / changed(그 사이 내용이 바뀌어 못 찾음) / fail
function Edit-SavedLine($e) {
    $f = [string]$e.Path
    if (-not (Test-Path -LiteralPath $f)) { return 'fail' }
    if ($script:OutFile -and $f -eq $script:OutFile) { if (-not (Save-Unsaved)) { return 'fail' } }
    $txt = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.AddRange([string[]]([regex]::Split($txt, '\r?\n')))
    $old = @($e.Old)
    if ($old.Count -lt 1 -or $old[0] -notmatch '^\[[\d:]+\]') { return 'fail' }
    $match = {
        param($at)
        if ($at -lt 0 -or $at + $old.Count -gt $lines.Count) { return $false }
        for ($k = 0; $k -lt $old.Count; $k++) { if ($lines[$at + $k].TrimEnd() -ne ([string]$old[$k]).TrimEnd()) { return $false } }
        return $true
    }
    $at = -1
    if (& $match ([int]$e.Start)) { $at = [int]$e.Start }
    else {
        $found = @()
        for ($j = 0; $j -lt $lines.Count; $j++) { if (& $match $j) { $found += $j } }
        if ($found.Count -eq 1) { $at = $found[0] }
    }
    if ($at -lt 0) { return 'changed' }
    $m = [regex]::Match([string]$old[0], '^(\[[\d:]+\]\s(?:(?:【[^】]*】)+\s?)?)(.*)$')
    $prefix = $m.Groups[1].Value
    $oldBody = (@($m.Groups[2].Value) + @($old | Select-Object -Skip 1 | ForEach-Object { ([string]$_).Trim() })) -join ' '
    $newBody = (([string]$e.Text) -replace '[\r\n\t]+', ' ' -replace '\s{2,}', ' ').Trim()
    $lines.RemoveRange($at, $old.Count)
    if ($newBody) {
        if ($prefix -notmatch '\s$') { $prefix += ' ' }
        $lines.Insert($at, $prefix + $newBody)
    }
    [void](Set-FileTextSafe $f ($lines -join "`r`n"))
    # 목차 파일의 같은 문장 줄(쪽수·키워드가 있는 문장)도 고침
    $idx = [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($f), [System.IO.Path]::GetFileNameWithoutExtension($f) + '_목차.txt')
    $stamp = [regex]::Match([string]$old[0], '^\[([\d:]+)\]').Groups[1].Value
    if ((Test-Path -LiteralPath $idx) -and $stamp) {
        try {
            $brief = { param($t) if ($t.Length -gt 60) { $t.Substring(0, 60) + '…' } else { $t } }
            $ob = & $brief $oldBody
            $itxt = [System.IO.File]::ReadAllText($idx, [System.Text.Encoding]::UTF8)
            $il = [regex]::Split($itxt, '\r?\n')
            for ($j = 0; $j -lt $il.Count; $j++) {
                if ($il[$j].StartsWith("[$stamp]") -and $il[$j].EndsWith(' ' + $ob)) {
                    if ($newBody) { $il[$j] = $il[$j].Substring(0, $il[$j].Length - $ob.Length) + (& $brief $newBody) }
                    else { $il[$j] = $null }
                    [void](Set-FileTextSafe $idx ((@($il | Where-Object { $null -ne $_ })) -join "`r`n"))
                    break
                }
            }
        } catch { }
    }
    return 'ok'
}

function Invoke-PendingEdits {
    while ($sync.EditQueue.Count -gt 0) {
        $e = $sync.EditQueue[0]; $sync.EditQueue.RemoveAt(0)
        $r = 'fail'
        try { $r = Edit-SavedLine $e } catch { $r = 'fail' }
        if ($r -eq 'ok') { Write-Host ("[고침 저장] {0}" -f [System.IO.Path]::GetFileName([string]$e.Path)) -ForegroundColor Green }
        $sync.EditResults[[string]$e.Id] = $r
    }
}

# 위원 명단(자주 틀리는 이름 포함)을 나중에 고쳐도, 이번에 받아쓴 파일의 구분선·목차 이름을 다시 바로잡음
function Repair-MemberLabels {
    if ($script:sessionCount -lt 1 -or $Roster.Count -eq 0 -or -not $script:OutFile) { return }
    if ($script:current -and $script:currentHeard) { $script:current = Format-Member $script:currentHeard; Set-Title }
    if (-not (Save-Unsaved)) { return }
    $rx = '(─+ [▶■] )([가-힣]{1,10}) 위원(?:\((?:명단에 없음|자막: ([^)\s]+))\))?( 질의)'
    $ev = [System.Text.RegularExpressions.MatchEvaluator]{
        param($m)
        $heard = $m.Groups[2].Value
        if ($m.Groups[3].Success) { $heard = $m.Groups[3].Value }
        return $m.Groups[1].Value + (Format-Member $heard) + $m.Groups[4].Value
    }
    # 목차의 쪽수·키워드 줄 '(홍길선 위원)'도 '(홍길동 위원)'으로 바로잡음
    $rxIdx = '(?m)^(\[[\d:]+\]\s+(?:【[^】]*】)+ \()([가-힣]{1,10}) 위원(\) )'
    $evIdx = [System.Text.RegularExpressions.MatchEvaluator]{
        param($m)
        return $m.Groups[1].Value + ((Format-Member $m.Groups[2].Value) -replace '\(.*\)', '') + $m.Groups[3].Value
    }
    $n = 0
    foreach ($f in @($script:OutFile, $script:IndexFile)) {
        if (-not $f -or -not (Test-Path -LiteralPath $f)) { continue }
        try {
            $old = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
            $new = [regex]::Replace($old, $rx, $ev)
            if ($f -eq $script:IndexFile) { $new = [regex]::Replace($new, $rxIdx, $evIdx) }
            if ($new -ne $old) {
                # 임시 파일에 다 쓴 뒤에 한 번에 바꿔 끼움 (쓰는 도중 꺼져도 원래 파일은 그대로 남음)
                $tmp = $f + '.tmp'
                try {
                    [System.IO.File]::WriteAllText($tmp, $new, $utf8Bom)
                    [System.IO.File]::Replace($tmp, $f, [NullString]::Value)
                } finally {
                    if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
                }
                if ($f -eq $script:OutFile) { $n = @([regex]::Matches($old, $rx)).Count }
            }
        } catch { Write-Host "[안내] 이미 기록된 위원 이름을 바로잡지 못했습니다(파일이 열려 있음). 받아쓰기는 계속됩니다." -ForegroundColor DarkYellow }
    }
    if ($n -gt 0) { Write-Host "[이름 바로잡음] 바뀐 위원 명단에 맞춰 이미 기록된 구분선·목차의 이름을 다시 정리했습니다." -ForegroundColor Green }
}

[void](Import-Settings)

# ───────────────────────── 이름 보정 ─────────────────────────

$Cho  = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ'
$Jung = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ'
$Jong = @('', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ')

# 한글을 자모로 풀어 씀 (홍길동 → ㅎㅗㅇㄱㅣㄹㄷㅗㅇ)
function Split-Jamo([string]$s) {
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $s.ToCharArray()) {
        $c = [int]$ch - 0xAC00
        if ($c -lt 0 -or $c -gt 11171) { [void]$sb.Append($ch); continue }
        [void]$sb.Append($Cho[[Math]::Floor($c / 588)])
        [void]$sb.Append($Jung[[Math]::Floor(($c % 588) / 28)])
        [void]$sb.Append($Jong[$c % 28])
    }
    return $sb.ToString()
}

function Get-EditDistance([string]$a, [string]$b) {
    $n = $a.Length; $m = $b.Length
    $prev = New-Object int[] ($m + 1)
    $cur = New-Object int[] ($m + 1)
    for ($j = 0; $j -le $m; $j++) { $prev[$j] = $j }
    for ($i = 1; $i -le $n; $i++) {
        $cur[0] = $i
        for ($j = 1; $j -le $m; $j++) {
            $cost = 1; if ($a[$i - 1] -eq $b[$j - 1]) { $cost = 0 }
            $v = [Math]::Min($prev[$j] + 1, $cur[$j - 1] + 1)
            $cur[$j] = [Math]::Min($v, $prev[$j - 1] + $cost)
        }
        $t = $prev; $prev = $cur; $cur = $t
    }
    return $prev[$m]
}

# 들린 이름을 명단에서 가장 가까운 이름으로 바꿈. 반환: @(표시이름, 보정여부)
function Resolve-MemberName([string]$heard) {
    if ($Roster.Count -eq 0) { return @($heard, $false) }
    $hj = Split-Jamo $heard
    $best = $null; $bestScore = 999.0
    foreach ($r in $Roster) {
        foreach ($f in $r.Forms) {
            if ($f -eq $heard) { return @($r.Name, ($r.Name -ne $heard)) }
            $fj = Split-Jamo $f
            $d = [double](Get-EditDistance $hj $fj)
            # 성(첫 글자)이 같으면 조금 더 가깝게, 이름 끝 글자만 들린 경우(길동↔홍길동)도 고려
            if ($heard[0] -eq $f[0]) { $d -= 0.5 }
            $score = $d / [Math]::Max($hj.Length, $fj.Length)
            if ($score -lt $bestScore) { $bestScore = $score; $best = $r.Name }
        }
    }
    if ($bestScore -le 0.5) { return @($best, ($best -ne $heard)) }
    return @($heard, $false)
}

function Format-Member([string]$heard) {
    $r = Resolve-MemberName $heard
    if ($r[1]) { return ("{0} 위원(자막: {1})" -f $r[0], $heard) }
    if ($Roster.Count -gt 0 -and -not ($Roster | Where-Object { $_.Name -eq $r[0] })) { return ("{0} 위원(명단에 없음)" -f $r[0]) }
    return ("{0} 위원" -f $r[0])
}

# ───────────────────────── 쪽수·키워드 ─────────────────────────

function Convert-KoreanNumber([string]$s) {
    $digits = @{ '일' = 1; '이' = 2; '삼' = 3; '사' = 4; '오' = 5; '육' = 6; '칠' = 7; '팔' = 8; '구' = 9 }
    $units = @{ '십' = 10; '백' = 100; '천' = 1000 }
    $total = 0; $cur = 0
    foreach ($ch in $s.ToCharArray()) {
        $c = [string]$ch
        if ($digits.ContainsKey($c)) { $cur = $digits[$c] }
        elseif ($units.ContainsKey($c)) { if ($cur -eq 0) { $cur = 1 }; $total += $cur * $units[$c]; $cur = 0 }
    }
    return $total + $cur
}

function Get-Pages([string]$t) {
    $pages = New-Object System.Collections.Generic.List[string]
    foreach ($m in [regex]::Matches($t, '(?<![\d.])(\d{1,4})\s*(?:페이지|쪽|page)')) {
        $v = $m.Groups[1].Value
        if ([int]$v -gt 0 -and -not $pages.Contains($v)) { $pages.Add($v) }
    }
    # 한글로 적힌 쪽수(오백팔십페이지). '이쪽', '그쪽'과 헷갈리지 않게 십·백·천이 들어간 것만
    foreach ($m in [regex]::Matches($t, '([일이삼사오육칠팔구십백천]{2,})\s*(?:페이지|쪽)')) {
        $w = $m.Groups[1].Value
        if ($w -notmatch '[십백천]') { continue }
        $v = [string](Convert-KoreanNumber $w)
        if ($v -ne '0' -and -not $pages.Contains($v)) { $pages.Add($v) }
    }
    return $pages.ToArray()
}

function Get-KeywordHits([string]$t) {
    $hits = New-Object System.Collections.Generic.List[string]
    if ($Keywords.Count -eq 0) { return $hits.ToArray() }
    $k = ($t -replace '[\s?!,.]', '')
    foreach ($kw in $Keywords) { if ($k.Contains($kw.Key) -and -not $hits.Contains($kw.Show)) { $hits.Add($kw.Show) } }
    return $hits.ToArray()
}

# ───────────────────────── 긴 줄 나누기 ─────────────────────────

function Split-LongLine([string]$t, [int]$max) {
    $lines = New-Object System.Collections.Generic.List[string]
    $min = [Math]::Floor($max / 2)
    while ($t.Length -gt $max) {
        $head = $t.Substring(0, $max + 1)
        $cut = -1
        # 말이 이어지는 자리(…는데, …고, …서, 쉼표 등) 뒤에서 우선 나눔
        $ms = [regex]::Matches($head, '(?:,|는데|은데|ㄴ데|고요|구요|데요|니까|지만|면서|어서|아서|해서|하고|이고|으며|하며|되고|었고|았고|인데)\s')
        for ($i = $ms.Count - 1; $i -ge 0; $i--) {
            $p = $ms[$i].Index + $ms[$i].Length
            if ($p -ge $min) { $cut = $p; break }
        }
        if ($cut -lt 0) { $cut = $head.LastIndexOf(' ') + 1 }
        if ($cut -lt $min) { $cut = $max }
        $lines.Add($t.Substring(0, $cut).TrimEnd())
        $t = $t.Substring($cut).TrimStart()
    }
    if ($t) { $lines.Add($t) }
    return $lines.ToArray()
}

# ───────────────────────── 위원장 진행 멘트 ─────────────────────────

# '홍길동 의원님 말씀해 주십시오', '홍길동 의원님 말씀하십시오', '홍길동 의원이 말씀해 주시기 바랍니다' 등
$RxCallTail = '(?:(?:말씀|질의|발언|질문)\s*(?:해|하여|하여서)?\s*주(?:십시오|시기|세요|시죠|시지요|십쇼)|(?:말씀|질의|발언|질문)\s*하(?:십시오|세요|시죠|시지요|십쇼))'
$RxStart  = '([가-힣]{2,5})\s*(?:의원|위원)(?:님|이)?\s*[,.]?\s*' + $RxCallTail
# '수고하셨습니다', '고생하셨습니다' (이름 뒤 쉼표도 허용)
$RxEnd    = '([가-힣]{2,5})\s*(?:(?:의원|위원)님|님)\s*[,.]?\s*(?:수고|고생)(?:하셨|많으셨)'
# 이름을 못 알아들은 호명('이 말씀해 주시기 바랍니다'): 위원장이 '질의하실 위원님 계십니까?'라고 물은 직후의 짧은 줄만 인정
$RxNamelessCall = '^\s*(?:네|예)?[,.]?\s*(?:[가-힣]{1,4}\s+)?' + $RxCallTail
$RxAsk    = '질의(?:하실|할)\s*(?:의원|위원)'
$RxChair  = '(?:제가|위원장이)\s*(?:몇\s*가지|한두\s*가지|간단히|잠깐)?\s*(?:만)?\s*질의'
$RxUnitEnd  = '([가-힣]{1,12}(?:\s?극|국|과|실|원|청|단|관))\s*소관.{0,20}?마치(?:겠습니다|도록|려고|고자)'
$RxUnitNext = '([가-힣]{1,12}국)장님?\s*(?:께서는|께서|은|는)\s*(?:답변)?\s*준비'

$script:current = $null        # 지금 질의 중인 위원(표시 이름)
$script:sinceAsk = 99          # 위원장이 '질의하실 위원님 계십니까?'라고 물은 뒤 지난 줄 수
$script:currentHeard = ''
$script:currentStart = ''
$script:lastPage = ''
$script:lastSound = [datetime]::MinValue

function Set-Title {
    if ($script:idle) {
        try { $Host.UI.RawUI.WindowTitle = '[닫지 마세요] Live Notes 대기 중 | 보기 화면에서 [② 새 기록 시작]' } catch { }
        return
    }
    $t = '[닫지 마세요] Live Notes 받아쓰는 중'
    if ($script:paused) { $t = '[닫지 마세요] Live Notes 중지됨 | [받아쓰기 재개]를 누르면 이어서 저장' }
    if ($script:current) { $t += " | 질의 중: $($script:current) ($($script:currentStart)~)" }
    if ($script:lastPage) { $t += " | 최근 언급: $($script:lastPage)쪽" }
    try { $Host.UI.RawUI.WindowTitle = $t } catch { }
}

# '홍길동 위원(자막: 홍길선)'과 '홍길동 위원'은 같은 위원 (같은 위원을 다시 부르면 구분선을 새로 긋지 않음)
function Test-SameMember([string]$a, [string]$b) {
    if (-not $a -or -not $b) { return $false }
    if ($a -match '못 알아들음' -or $b -match '못 알아들음') { return ($a -eq $b) }
    return (($a -replace '\(.*\)', '') -eq ($b -replace '\(.*\)', ''))
}

function Close-Member([string]$stamp, [string]$endWho) {
    if (-not $script:current) { return }
    # 이름을 못 알아들은 구간이 '홍길동 의원님 수고하셨습니다'로 끝나면, 그 이름을 구간 제목에 넣음
    if ($script:current -match '못 알아들음' -and $endWho) {
        $lab = Format-Member $endWho
        if ($lab -notmatch '명단에 없음') {
            $newLab = ($lab -replace '\(.*\)', '') + '(끝 인사로 확인)'
            $old = "▶ {0} 질의 [{1}]" -f $script:current, $script:currentStart
            $new = "▶ {0} 질의 [{1}]" -f $newLab, $script:currentStart
            for ($i = 0; $i -lt $unsaved.Count; $i++) { $unsaved[$i] = $unsaved[$i].Replace($old, $new) }
            for ($i = 0; $i -lt $unsavedIndex.Count; $i++) { $unsavedIndex[$i] = $unsavedIndex[$i].Replace($old, $new) }
            if (Save-Unsaved) {
                foreach ($f in @($script:OutFile, $script:IndexFile)) { [void](Update-FileText $f $old $new) }
            }
            $script:current = $newLab
        }
    }
    Add-Out ("──────── ■ {0} 질의 끝 ({1}~{2}) ────────" -f $script:current, $script:currentStart, $stamp) 'Sep' -Index
    Add-Out '' 'Plain'
    $script:current = $null; $script:currentHeard = ''
    Set-Title
}

function Open-Member([string]$label, [string]$heard, [string]$stamp) {
    Add-Out '' 'Plain'
    Add-Out ("──────── ▶ {0} 질의 [{1}] ────────" -f $label, $stamp) 'Sep' -Index
    $script:current = $label; $script:currentHeard = $heard; $script:currentStart = $stamp
    Set-Title
}

# ───────────────────────── 파일 쓰기 ─────────────────────────

$unsaved = New-Object System.Collections.Generic.List[string]
$unsavedIndex = New-Object System.Collections.Generic.List[string]
$script:savedCount = 0
$script:writeWarned = $false
$IndexFile = ''

$script:lastBlank = $true
function Add-Out([string]$text, [string]$style, [switch]$Index) {
    # 빈 줄은 두 줄 연달아 넣지 않음
    if (-not $text) { if ($script:lastBlank) { return }; $script:lastBlank = $true } else { $script:lastBlank = $false }
    $unsaved.Add($text + "`r`n")
    if ($Index) { $unsavedIndex.Add($text + "`r`n") }
    switch ($style) {
        'Sep'     { Write-Host $text -ForegroundColor Cyan }
        'Keyword' { Write-Host $text -ForegroundColor Black -BackgroundColor Yellow }
        'Page'    { Write-Host $text -ForegroundColor Yellow }
        'Plain'   { Write-Host $text }
        default   { Write-Host $text }
    }
}

$script:indexWarned = $false

function Save-Unsaved {
    $ok = $true
    if ($unsaved.Count -gt 0) {
        try {
            [System.IO.File]::AppendAllText($OutFile, ($unsaved -join ''), $utf8Bom)
            $unsaved.Clear()
            if ($script:writeWarned) {
                Write-Host "본문 파일 저장이 다시 정상화되었습니다." -ForegroundColor Green
                $script:writeWarned = $false
            }
        } catch {
            $ok = $false
            if (-not $script:writeWarned) {
                Write-Host "[경고] 본문 파일에 쓰지 못했습니다: $($_.Exception.Message)" -ForegroundColor Red
                Write-Host "       저장 파일을 다른 프로그램에서 열어 두었다면 닫아 주세요. 계속 재시도합니다." -ForegroundColor Red
                $script:writeWarned = $true
            }
        }
    }
    if ($unsavedIndex.Count -gt 0 -and $IndexFile) {
        try {
            [System.IO.File]::AppendAllText($IndexFile, ($unsavedIndex -join ''), $utf8Bom)
            $unsavedIndex.Clear()
            if ($script:indexWarned) {
                Write-Host "목차 파일 저장이 다시 정상화되었습니다." -ForegroundColor Green
                $script:indexWarned = $false
            }
        } catch {
            $ok = $false
            if (-not $script:indexWarned) {
                Write-Host "[경고] 목차 파일에 쓰지 못했습니다: $($_.Exception.Message)" -ForegroundColor Red
                Write-Host "       목차 파일을 열어 두었다면 닫아 주세요. 본문은 따로 저장되며, 목차는 계속 재시도합니다." -ForegroundColor Red
                $script:indexWarned = $true
            }
        }
    }
    return $ok
}

function Get-Stamp {
    if ($script:replayStamp) { return $script:replayStamp }
    if ($ClockTime) { return ("{0:HH:mm:ss}" -f (Get-Date)) }
    $e = (Get-Date) - $startTime
    if ($e.TotalHours -ge 1) { return ("{0}:{1:00}:{2:00}" -f [int][Math]::Floor($e.TotalHours), $e.Minutes, $e.Seconds) }
    return ("{0:00}:{1:00}" -f $e.Minutes, $e.Seconds)
}

# 비교용 열쇠: 띄어쓰기와 문장부호를 뺀 글자만 남김
function Get-Key([string]$s) {
    $k = $s -replace '(?<!\d)\.|\.(?!\d)', ''      # 숫자 사이의 소수점만 남김 (1.5 와 15 구분)
    return ($k -replace '[\s?!,]', '')
}

$writtenKeys = New-Object System.Collections.Generic.List[string]

function Write-Sentence([string]$s) {
    $writtenKeys.Add((Get-Key $s))
    $t = $s -replace '\s+([.?!,])', '$1'
    $t = $t -replace '(\d)\s+(년도|년|월|명|개소|건|곳|쪽|페이지|퍼센트|프로|%|회|학급)', '$1$2'
    $t = $t -replace '([A-Za-z]{2,})\s+(가|는|로|를|의|에|도|와|나)(?=[\s.,?!]|$)', '$1$2'
    # 위원장 멘트와 위원의 첫 질문이 마침표 없이 한 줄로 이어진 경우 두 줄로 나눔
    #   '홍길동 의원님 말씀해 주시기 바랍니다 그 페이지 357페이지…' → 호명 줄 + 질문 줄(질문은 그 위원 구간에 들어감)
    foreach ($rx in @(($RxEnd + '[가-힣]*'), ($RxStart + '(?:\s*바랍니다)?'))) {
        $m = [regex]::Match($t, $rx)
        if (-not $m.Success) { continue }
        if ($rx -eq ($RxEnd + '[가-힣]*') -and $m.Value -notmatch '(?:의원|위원)님') { continue }
        $cut = $m.Index + $m.Length
        $head = $t.Substring(0, $cut).Trim()
        $rest = ($t.Substring($cut) -replace '^[\s.,?!]+', '').Trim()
        if ((Get-Key $rest).Length -lt 6) { continue }
        if ($t[$cut - 1] -notmatch '[.?!]') { $head += '.' }
        Write-Part $head
        Write-Part $rest
        return
    }
    Write-Part $t
}

function Write-Part([string]$t) {
    $stamp = Get-Stamp

    # 1) 위원장 진행 멘트 찾기
    $mEnd = [regex]::Match($t, $RxEnd)
    $endOk = $false
    if ($mEnd.Success) {
        $who = $mEnd.Groups[1].Value
        $isMember = ($mEnd.Value -match '(?:의원|위원)님')
        # '○○○ 국장님 수고하셨습니다' 같은 공무원 인사는 제외
        if ($isMember -or ($script:current -and $who -notmatch '(?:장|감|관|님)$')) { $endOk = $true }
    }
    $mStart = [regex]::Match($t, $RxStart)
    $startLabel = $null; $startHeard = ''
    if ($mStart.Success -and (-not $mEnd.Success -or $mStart.Index -gt $mEnd.Index)) {
        $startHeard = $mStart.Groups[1].Value
        $startLabel = Format-Member $startHeard
    } elseif ($t -match $RxChair -and $script:current -ne '위원장') {
        $startLabel = '위원장'; $startHeard = '위원장'
    } elseif (-not $script:current -and $script:sinceAsk -le 2 -and $t.Length -le 30 -and $t -match $RxNamelessCall -and $t -notmatch '(?:의원|위원|장님|감님|관님)') {
        $startLabel = '위원(이름 못 알아들음)'; $startHeard = ''
    }
    if ($t -match $RxAsk) { $script:sinceAsk = 0 } else { $script:sinceAsk++ }
    $mUnitEnd = [regex]::Match($t, $RxUnitEnd)
    $mUnitNext = [regex]::Match($t, $RxUnitNext)

    # 구분선(시작)은 그 줄 앞에: 같은 위원이 다시 불린 것이면 새로 긋지 않음
    $startBefore = $false
    if ($startLabel -and -not $endOk) {
        if (-not (Test-SameMember $startLabel $script:current)) {
            Close-Member $stamp
            Open-Member $startLabel $startHeard $stamp
        }
        $startLabel = $null
    }

    # 2) 쪽수·키워드
    $pages = @(Get-Pages $t)
    $hits = @(Get-KeywordHits $t)
    $tag = ''
    foreach ($p in $pages) { $tag += "【$($p)쪽】" }
    foreach ($h in $hits) { $tag += "【★$h】" }
    if ($pages.Count -gt 0) { $script:lastPage = $pages[$pages.Count - 1]; Set-Title }

    # 3) 본문 (긴 줄은 나눔)
    $prefix = "[$stamp] "
    if ($tag) { $prefix += "$tag " }
    $style = 'Plain'
    if ($pages.Count -gt 0) { $style = 'Page' }
    if ($hits.Count -gt 0) { $style = 'Keyword' }
    $chunks = @(Split-LongLine $t $MaxLineLength)
    $indent = ' ' * ($stamp.Length + 3)
    for ($i = 0; $i -lt $chunks.Count; $i++) {
        if ($i -eq 0) { Add-Out ($prefix + $chunks[$i]) $style } else { Add-Out ($indent + $chunks[$i]) $style }
    }
    $script:savedCount++

    if ($tag) {
        $who = ''
        if ($script:current) { $who = " (" + ($script:current -replace '\(.*\)', '') + ")" }
        $brief = $t; if ($brief.Length -gt 60) { $brief = $brief.Substring(0, 60) + '…' }
        $unsavedIndex.Add(("[{0}]    {1}{2} {3}`r`n" -f $stamp, $tag, $who, $brief))
    }
    if ($hits.Count -gt 0 -and -not $NoSound -and -not $Replay) {
        if (((Get-Date) - $script:lastSound).TotalSeconds -ge 5) {
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch { }
            $script:lastSound = Get-Date
        }
    }

    # 구분선(끝)은 그 줄 뒤에
    if ($endOk) { Close-Member $stamp $mEnd.Groups[1].Value }
    if ($startLabel -and -not (Test-SameMember $startLabel $script:current)) { Open-Member $startLabel $startHeard $stamp }
    if ($mUnitEnd.Success) {
        Close-Member $stamp
        $unit = $mUnitEnd.Groups[1].Value -replace '\s?극$', '국'      # '정책 극소관'처럼 잘못 들린 경우
        Add-Out ("════════ {0} 소관 질의 답변 종료 [{1}] ════════" -f $unit, $stamp) 'Sep' -Index
        Add-Out '' 'Plain'
    }
    if ($mUnitNext.Success) {
        Close-Member $stamp
        Add-Out ("════════ 다음 순서: {0} [{1}] ════════" -f $mUnitNext.Groups[1].Value, $stamp) 'Sep' -Index
        Add-Out '' 'Plain'
    }
    [void](Save-Unsaved)
}

# ───────────────────────── 마무리 저장 ─────────────────────────
# 반환: 0 정상 저장, 1 일부를 복구 파일에 따로 저장(확인 필요), 2 저장하지 못한 내용 있음
function Complete-Save {
    [void](Save-Unsaved)
    $code = 0
    if ($unsaved.Count -eq 0) {
        Write-Host ("`n저장을 마쳤습니다: {0} (총 {1}문장)" -f $OutFile, $script:savedCount)
    } else {
        # 끝까지 못 쓴 본문 줄은 다른 이름의 파일로 살려 둠
        $rescue = [System.IO.Path]::ChangeExtension($OutFile, $null).TrimEnd('.') + '_복구.txt'
        try {
            [System.IO.File]::AppendAllText($rescue, ($unsaved -join ''), $utf8Bom)
            Write-Host ("`n[주의] 본문 파일에 쓰지 못한 {0}줄을 다음 파일에 따로 저장했습니다: {1}" -f $unsaved.Count, $rescue) -ForegroundColor Red
            $code = 1
        } catch {
            Write-Host ("`n[오류] 본문 {0}줄을 저장하지 못했습니다. 위 화면의 내용을 복사해 두세요." -f $unsaved.Count) -ForegroundColor Red
            $code = 2
        }
    }
    if ($unsavedIndex.Count -eq 0) {
        Write-Host ("목차 파일: {0}" -f $IndexFile)
    } else {
        $rescueIdx = [System.IO.Path]::ChangeExtension($IndexFile, $null).TrimEnd('.') + '_복구.txt'
        try {
            [System.IO.File]::AppendAllText($rescueIdx, ($unsavedIndex -join ''), $utf8Bom)
            Write-Host ("[주의] 목차 파일에 쓰지 못한 {0}줄을 다음 파일에 따로 저장했습니다: {1}" -f $unsavedIndex.Count, $rescueIdx) -ForegroundColor Red
            if ($code -lt 1) { $code = 1 }
        } catch {
            Write-Host ("[오류] 목차 {0}줄을 저장하지 못했습니다. (본문 파일에는 영향 없음)" -f $unsavedIndex.Count) -ForegroundColor Red
            $code = 2
        }
    }
    return $code
}

# ───────────────────────── 저장 파일 준비 ─────────────────────────

function Initialize-OutFile {
    $outDir = Split-Path -Parent $script:OutFile
    if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }
    # 같은 이름의 파일이 이미 있으면 뒤에 번호를 붙여 새 파일로 저장 (기존 파일에 이어 쓰지 않음)
    if (Test-Path -LiteralPath $script:OutFile) {
        $base = [System.IO.Path]::Combine($outDir, [System.IO.Path]::GetFileNameWithoutExtension($script:OutFile))
        $ext = [System.IO.Path]::GetExtension($script:OutFile)
        $n = 2
        while (Test-Path -LiteralPath ("{0}_{1}{2}" -f $base, $n, $ext)) { $n++ }
        $script:OutFile = "{0}_{1}{2}" -f $base, $n, $ext
    }
    $script:IndexFile = [System.IO.Path]::Combine($outDir, [System.IO.Path]::GetFileNameWithoutExtension($script:OutFile) + '_목차.txt')
}

function Write-Headers([datetime]$t0) {
    $header = "시작 시각: {0:yyyy-MM-dd HH:mm:ss}`r`n" -f $t0
    $header += "※ 자동 받아쓰기 초안입니다. 이름·사업명·수치는 원본 영상과 대조가 필요합니다.`r`n"
    $header += "※ 숫자는 특히 틀리기 쉽습니다(예: 962개소 → 이백육십이). 답변 자료의 수치는 다시보기로 꼭 확인하세요.`r`n`r`n"
    [System.IO.File]::AppendAllText($OutFile, $header, $utf8Bom)
    $ih = "목차 (위원별 질의 구간, 쪽수·키워드 언급)  시작 {0:yyyy-MM-dd HH:mm}`r`n본문: {1}`r`n`r`n" -f $t0, [System.IO.Path]::GetFileName($OutFile)
    [System.IO.File]::AppendAllText($IndexFile, $ih, $utf8Bom)
}

function Show-Settings {
    if ($Roster.Count -gt 0) { Write-Host ("위원 명단 {0}명을 불러왔습니다." -f $Roster.Count) }
    else { Write-Host "위원 명단이 비어 있습니다. 보기 화면의 [설정]에서 입력하면 이름 보정이 켜집니다." -ForegroundColor DarkYellow }
    if ($Keywords.Count -gt 0) { Write-Host ("관심 키워드 {0}개: {1}" -f $Keywords.Count, (($Keywords | ForEach-Object { $_.Show }) -join ', ')) }
    else { Write-Host "관심 키워드가 없습니다. 보기 화면의 [설정]에서 부서·사업명을 입력하면 강조·알림이 켜집니다." -ForegroundColor DarkYellow }
    Write-Host "(위원 명단·관심 키워드는 실행 중에 바꿔도 몇 초 안에 반영됩니다.)"
}

# ───────────────────────── 저장 파일 다시 정리(점검용) ─────────────────────────

if ($Replay) {
    if (-not (Test-Path -LiteralPath $Replay)) { Write-Host "파일을 찾지 못했습니다: $Replay" -ForegroundColor Red; exit 2 }
    if (-not $PSBoundParameters.ContainsKey('OutFile')) {
        $OutFile = [System.IO.Path]::Combine((Split-Path -Parent (Resolve-Path -LiteralPath $Replay)), [System.IO.Path]::GetFileNameWithoutExtension($Replay) + '_정리.txt')
    }
    Initialize-OutFile
    Show-Settings
    $startTime = Get-Date
    Write-Headers $startTime
    # 시각으로 시작하는 줄이 한 문장. 들여쓰기로 이어지는 줄(긴 발언을 나눠 쓴 줄)은 앞 문장에 붙임
    $entries = New-Object System.Collections.Generic.List[object]
    foreach ($l in (Read-ListFile $Replay -Raw)) {
        $l = $l.TrimStart([char]0xFEFF)
        $m = [regex]::Match($l, '^\[(\d{1,2}:\d{2}(?::\d{2})?)\]\s*(.*)$')
        if ($m.Success) {
            $body = $m.Groups[2].Value -replace '^(?:【[^】]*】)+\s*', ''
            $entries.Add([pscustomobject]@{ Stamp = $m.Groups[1].Value; Body = $body })
        } elseif ($entries.Count -gt 0 -and $l -match '^\s+\S' -and $l.Trim() -notmatch '^[─═]') {
            $last = $entries[$entries.Count - 1]
            $last.Body = ($last.Body.TrimEnd() + ' ' + $l.Trim())
        }
    }
    foreach ($e in $entries) {
        $script:replayStamp = $e.Stamp
        if ($e.Body.Trim()) { Write-Sentence $e.Body; $script:replayLast = $e.Stamp }
    }
    $script:replayStamp = $null
    Close-Member $script:replayLast
    $code = Complete-Save
    exit $code
}

# ───────────────────────── 실시간 저장 ─────────────────────────

# 이미 실행 중인 프로그램의 보기 화면 주소 찾기
# 반환: @{ Url = 보기 화면 주소; Viewer = 지금 열려 있는 보기 화면이 있는지 } 또는 $null
#   (/api/ping은 '보기 화면이 다시 연결됨'으로 세지 않음. 브라우저를 닫은 직후라면 Viewer=$false)
function Find-RunningViewer {
    for ($p = $ViewerPort; $p -lt $ViewerPort + 20; $p++) {
        try {
            $req = [System.Net.HttpWebRequest]::Create("http://127.0.0.1:$p/api/ping?attention=1")
            $req.Proxy = $null
            $req.Timeout = 700
            $resp = $req.GetResponse()
            try {
                $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                $t = $sr.ReadToEnd()
            } finally { $resp.Close() }
            if ($t -match '"app"\s*:\s*"livecaptions"') { return @{ Url = "http://127.0.0.1:$p/"; Viewer = ($t -match '"viewer"\s*:\s*true') } }
        } catch { }
    }
    return $null
}

# 중복 실행 방지: 이미 실행 중이면 그 프로그램의 보기 화면을 다시 열어 주고 끝냄
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, 'SaveLiveCaptions_SingleInstance', [ref]$createdNew)
if (-not $createdNew) {
    $mutex.Dispose()
    Write-Host "받아쓰기 프로그램이 이미 실행 중입니다."
    $running = $null
    if (-not $NoViewer) { $running = Find-RunningViewer }
    if ($running) {
        $shown = $false
        if ($running.Viewer -and -not $NoBrowser) {
            # 이미 열려 있는 받아쓰기 화면(브라우저 창)을 앞으로 가져옴. 새 창은 열지 않음
            try {
                Add-Type -TypeDefinition @'
using System; using System.Text; using System.Runtime.InteropServices;
public static class ViewerWin {
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
    public static bool Bring(string title) {
        IntPtr found = IntPtr.Zero;
        EnumWindows(delegate (IntPtr h, IntPtr l) {
            if (!IsWindowVisible(h)) return true;
            StringBuilder sb = new StringBuilder(512);
            GetWindowText(h, sb, 512);
            if (sb.ToString().StartsWith(title)) { found = h; return false; }
            return true;
        }, IntPtr.Zero);
        if (found == IntPtr.Zero) return false;
        if (IsIconic(found)) ShowWindow(found, 9);
        SetForegroundWindow(found);
        return true;
    }
}
'@ -ErrorAction Stop
                $shown = [ViewerWin]::Bring('Live Notes - 의회방송')
            } catch { }
            if (-not $shown) { $shown = $true }   # 창을 못 찾아도(다른 탭에 가려진 경우 등) 화면은 열려 있으므로 새로 열지 않음
            Write-Host "이미 열려 있는 받아쓰기 화면을 그대로 쓰세요."
        }
        if (-not $shown) {
            Write-Host "실행 중인 보기 화면을 다시 엽니다: $($running.Url)"
            if (-not $NoBrowser -and -not $FromViewer) { try { Start-Process $running.Url } catch { } }
        }
    } else {
        Write-Host "(먼저 실행한 검은 창에서 Ctrl+C 로 끝낸 뒤 다시 실행하세요.)"
        exit 7   # 실행 중인 프로그램의 보기 화면을 찾지 못함 (실행 파일 창에 안내를 남김)
    }
    exit 3   # 이미 열린 보기 화면을 앞으로 가져오거나 다시 열었음 (실행 파일 창은 조용히 닫힘)
}

$SimLines = $null
$simIdx = 0
if ($Simulate) {
    $SimLines = @(Read-ListFile $Simulate -Raw | Where-Object { $_ -ne '' })
} else {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
    $AE = [System.Windows.Automation.AutomationElement]
}

function Get-CaptionElement {
    $proc = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $proc) { return $null }
    $pidCond = New-Object System.Windows.Automation.PropertyCondition($AE::ProcessIdProperty, $proc.Id)
    $win = $AE::RootElement.FindFirst([System.Windows.Automation.TreeScope]::Children, $pidCond)
    if (-not $win) { return $null }
    $script:elementPid = $proc.Id
    $idCond = New-Object System.Windows.Automation.PropertyCondition($AE::AutomationIdProperty, 'CaptionsTextBlock')
    return $win.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $idCond)
}

function Start-LiveCaptions {
    if (Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue) { return }
    try {
        Start-Process -FilePath 'LiveCaptions.exe' -ErrorAction Stop
        Write-Host "라이브 캡션을 자동으로 켰습니다."
    } catch {
        Write-Host "라이브 캡션을 자동으로 켜지 못했습니다. Win+Ctrl+L 을 직접 눌러 주세요."
    }
}

# 두 문장이 사실상 같은 문장인지(자막이 뒤늦게 조금 고쳐진 경우 포함)
function Test-Similar([string]$a, [string]$b) {
    if ($a -eq $b) { return $true }
    # 자막 창에서 앞부분이 잘려 보이는 같은 문장(15글자 이상이 다른 문장 안에 그대로 들어 있음)
    if ($a.Length -ge 15 -and $b.Contains($a)) { return $true }
    if ($b.Length -ge 15 -and $a.Contains($b)) { return $true }
    # 숫자·단위가 하나라도 다르면 다른 문장으로 취급
    # (15억과 50억, 15억과 15만, 십오억과 오십억을 같은 문장으로 보지 않음. 애매하면 둘 다 남김)
    if ((Get-NumberSig $a) -ne (Get-NumberSig $b)) { return $false }
    $max = [Math]::Max($a.Length, $b.Length)
    $min = [Math]::Min($a.Length, $b.Length)
    if ($max -lt 6) { return $false }
    $p = 0
    while ($p -lt $min -and $a[$p] -eq $b[$p]) { $p++ }
    $q = 0
    while ($q -lt ($min - $p) -and $a[$a.Length - 1 - $q] -eq $b[$b.Length - 1 - $q]) { $q++ }
    return (($p + $q) -ge [Math]::Floor($max * 0.7))
}

# 문장 속 수와 그 뒤 단위를 뽑아 차례대로 이어 붙임 (아라비아 숫자, 한글 숫자 모두)
#   15명/15건, 15억/15만, 십오억/오십억, 삼 명/사 명 을 서로 다르게 봄
$NumUnits = '퍼센트|페이지|개소|학급|년도|시간|프로|명|건|개|곳|원|번|회|년|월|일|분|초|쪽|대|교|세|살|차|배|권|부|석|주|호|층|위|등|%'
$RxNumArabic = '\d+(?:\.\d+)?[십백천만억조]*(?:' + $NumUnits + ')?'
$RxNumKorean = '[일이삼사오육칠팔구십백천만억조]+(?:' + $NumUnits + ')?'
function Get-NumberSig([string]$s) {
    $sig = New-Object System.Text.StringBuilder
    foreach ($m in [regex]::Matches($s, $RxNumArabic + '|' + $RxNumKorean)) {
        $v = $m.Value
        if ($v -notmatch '^\d') {
            # 한글 숫자는 '십·백·천·만·억·조'가 들었거나 바로 뒤에 단위가 붙은 것만 수로 봄
            # ('이제', '사업'처럼 낱말 속 글자는 제외. 단위가 붙은 '삼명', '사명'은 포함)
            $num = $v -replace ('(?:' + $NumUnits + ')$'), ''
            $hasUnit = ($num.Length -lt $v.Length)
            if ($v -notmatch '[십백천만억조]' -and -not $hasUnit) { continue }
            # 단위로 끝나지만 한 글자짜리 흔한 낱말(이번, 이분, 일부 등)은 양쪽 문장에 같이 있으므로 그대로 둬도 비교에 지장 없음
        }
        [void]$sig.Append($v).Append('|')
    }
    return $sig.ToString()
}

function Test-SimilarToAny([string]$k, $list) {
    foreach ($x in $list) { if (Test-Similar $k $x) { return $true } }
    return $false
}

# ── 문장부호 없이 길게 이어지는 발언 처리 ──
# 마침표 없이 계속 말하면 문장 전체가 '말하는 중' 조각으로 남는데, 자막 창에서 앞부분이 밀려나면 사라질 수 있음.
# 그래서 조각이 길어지면 앞부분을 미리 저장하고, 이미 저장한 부분의 끝 글자(꼬리)를 기억해 다음에 이어서 저장함.
$LongPendingKeyLen = 100   # 아직 저장 안 한 부분이 이 글자 수(띄어쓰기 제외)를 넘으면 앞부분을 미리 저장
$PendingKeepLen = 30       # 끝부분 이만큼은 자막이 고칠 수 있으니 남겨 둠
$script:flushedTail = ''   # 미리 저장한 부분의 마지막 글자들(비교용 열쇠)
$script:flushedAll = ''    # 미리 저장한 부분 전체(최근 600자, 비교용 열쇠)
$script:screenKeyMax = 0   # 지금까지 본 자막 창 글자 수(띄어쓰기 제외) 중 가장 큰 값
$script:flushedFromVanish = $false   # flushedTail이 '사라진 조각'으로 저장한 것에서 왔는지

# 원래 문장에서 열쇠 글자 n개가 끝나는 위치
function Get-RawIndex([string]$s, [int]$n) {
    $c = 0
    for ($i = 0; $i -lt $s.Length; $i++) {
        if ($c -ge $n) { return $i }
        $ch = $s[$i]
        $isKey = $true
        if ([char]::IsWhiteSpace($ch) -or $ch -eq '?' -or $ch -eq '!' -or $ch -eq ',') { $isKey = $false }
        elseif ($ch -eq '.') {
            $prevD = ($i -gt 0 -and [char]::IsDigit($s[$i - 1])); $nextD = ($i + 1 -lt $s.Length -and [char]::IsDigit($s[$i + 1]))
            if (-not ($prevD -and $nextD)) { $isKey = $false }
        }
        if ($isKey) { $c++ }
    }
    return $s.Length
}

# 문장에서 이미 미리 저장한 부분 뒤의 나머지. 꼬리를 못 찾으면 $null
function Get-AfterFlushed([string]$s) {
    if (-not $script:flushedTail) { return $null }
    $k = Get-Key $s
    $n = -1
    if ($script:flushedFromVanish) {
        # 사라진 것으로 보고 저장했던 조각(끝에 …)이 다시 나타나 문장이 이어진 경우:
        # 조각과 첫머리가 글자 그대로 같고, 조각이 낱말 끝에서 끝났을 때만 나머지를 이어 저장
        # (자막이 조각을 고쳐 다르게 나오면 고친 문장 전체를 다시 저장)
        $fa = $script:flushedAll
        if ($k.Length -le $fa.Length -or -not $k.StartsWith($fa, [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
        $raw = Get-RawIndex $s $fa.Length
        if ($raw -lt $s.Length -and -not [char]::IsWhiteSpace($s[$raw]) -and $s[$raw] -notmatch '[,.?!]') { return $null }
        return $s.Substring($raw).TrimStart(' ', ',').Trim()
    }
    # ① 미리 저장한 부분의 꼬리가 보이면 그 뒤부터
    $pos = $k.LastIndexOf($script:flushedTail)
    if ($pos -ge 0) { $n = $pos + $script:flushedTail.Length }
    else {
        # ② 꼬리가 화면에서 밀려났으면, 이미 저장한 부분의 '끝'과 지금 조각의 '시작'이
        #    실제로 똑같이 겹치는 길이만큼만 건너뜀 (첫 구절만 같고 뒤가 다르면 건너뛰지 않음)
        $maxL = [Math]::Min($k.Length, $script:flushedAll.Length)
        for ($L = $maxL; $L -ge 8; $L--) {
            if ($script:flushedAll.EndsWith($k.Substring(0, $L), [System.StringComparison]::Ordinal)) { $n = $L; break }
        }
    }
    if ($n -lt 0) { return $null }
    $raw = Get-RawIndex $s $n
    return $s.Substring($raw).Trim()
}

function Save-LongPending([string]$p) {
    $rest = $p
    if ($script:flushedTail) {
        $r = Get-AfterFlushed $p
        if ($null -ne $r) { $rest = $r }
    }
    $rk = Get-Key $rest
    # 자막 창에 담기는 글자 수가 적으면 더 일찍 저장 (창 크기의 절반 정도)
    #   자막 창이 작아 한 화면에 40글자도 안 담기면, 화면에서 밀려나기 전에 저장되도록 더 낮춤
    $limit = [Math]::Min($LongPendingKeyLen, [Math]::Max(16, [int]($script:screenKeyMax / 2)))
    $keep = [Math]::Min($PendingKeepLen, [int]($limit / 2))
    if ($rk.Length -lt $limit) { return }
    # 끝부분은 남기고 띄어쓰기 자리에서 자름
    $cutRaw = Get-RawIndex $rest ($rk.Length - $keep)
    $sp = $rest.LastIndexOf(' ', [Math]::Max(0, $cutRaw - 1))
    if ($sp -ge [Math]::Max(4, [int]($cutRaw / 3))) { $cutRaw = $sp }   # 낱말 중간에서 끊지 않음
    $head = $rest.Substring(0, $cutRaw).Trim()
    if (-not $head) { return }
    Write-Sentence ($head + ' …')
    $script:flushedFromVanish = $false
    $hk = Get-Key $head
    $script:flushedTail = $hk.Substring([Math]::Max(0, $hk.Length - 20))
    if ($rest -eq $p) { $script:flushedAll = '' }
    $script:flushedAll += $hk
    if ($script:flushedAll.Length -gt 600) { $script:flushedAll = $script:flushedAll.Substring($script:flushedAll.Length - 600) }
}

# 완성된 문장 저장. 앞부분을 미리 저장했던 문장이면 나머지만 저장
function Write-New([string]$s) {
    if ($script:flushedTail) {
        $r = Get-AfterFlushed $s
        if ($script:flushedFromVanish) {
            # 사라진 조각과 이어지는 문장인지는 바로 다음 문장에서만 봄
            $script:flushedFromVanish = $false
            if ($null -eq $r) { $script:flushedTail = ''; $script:flushedAll = '' }
        }
        if ($null -ne $r) {
            $script:flushedTail = ''; $script:flushedAll = ''
            if ((Get-Key $r).Length -gt 0) { Write-Sentence $r } else { $writtenKeys.Add('') }
            $writtenKeys[$writtenKeys.Count - 1] = (Get-Key $s)   # 화면에 다시 보이는 같은 문장을 중복 저장하지 않도록 전체 열쇠로 기억
            return
        }
    }
    Write-Sentence $s
}

# 화면에서 문장부호 없이 사라진 '말하는 중' 조각은 덮어써지기 전에 저장 (끝에 … 표시)
# 자막 창이 줄을 바꾸며 잠깐 깜빡이는 경우를 거르기 위해, 두 번 연속(약 2초) 안 보일 때만 저장하고
# 미리 저장한 적 없는 짧은 조각(띄어쓰기 빼고 8글자 미만)은 저장하지 않음
$VanishMinKeyLen = 8
$script:vanish = $null

function Test-OnScreen([string]$pk, [string]$screenKey) {
    $n = [Math]::Min(10, $pk.Length)
    if ($screenKey.Contains($pk.Substring($pk.Length - $n))) { return $true }
    $head = $pk.Substring(0, $n)
    $pos = $screenKey.IndexOf($head)
    if ($pos -lt 0) { return $false }
    # 앞부분만 같을 때: 이 조각에 든 수·단위(15명 등)가 화면의 이어지는 글에도 그대로 있어야 같은 말로 봄
    # (같은 구절로 다시 시작한 다른 발언이나 숫자가 바뀐 경우에는 앞 조각을 버리지 않고 남김)
    $sig = Get-NumberSig $pk
    if (-not $sig) { return $true }
    while ($pos -ge 0) {
        if ((Get-NumberSig $screenKey.Substring($pos)).StartsWith($sig)) { return $true }
        $pos = $screenKey.IndexOf($head, $pos + 1)
    }
    return $false
}

function Write-Vanished($v) {
    $rk = Get-Key $v.Rest
    $min = $VanishMinKeyLen
    if ($v.Flushed) { $min = 1 }
    if ($rk.Length -lt $min) { return }
    $tailCount = [Math]::Min(5, $writtenKeys.Count)
    if ($tailCount -gt 0 -and (Test-SimilarToAny $rk @($writtenKeys.GetRange($writtenKeys.Count - $tailCount, $tailCount)))) { return }
    Write-Sentence ($v.Rest + ' …')
    # 같은 문장이 다시 나타나 이어지면 겹치는 앞부분은 다시 쓰지 않도록 기억 (미리 저장한 조각이 아닌 경우만)
    if (-not $v.Flushed) {
        $script:flushedAll = $rk
        $script:flushedTail = $rk.Substring([Math]::Max(0, $rk.Length - 20))
        $script:flushedFromVanish = $true
    }
}

function Save-VanishedPending([string]$prev, [string]$screenKey) {
    # 지난번에 사라진 것으로 보인 조각: 이번에도 안 보이면 저장, 다시 보이면 취소
    if ($script:vanish) {
        $v = $script:vanish; $script:vanish = $null
        if (Test-OnScreen $v.Key $screenKey) {
            if (-not $script:flushedTail) { $script:flushedTail = $v.Tail; $script:flushedAll = $v.All; $script:flushedFromVanish = $v.FromVanish }
        } else {
            Write-Vanished $v
        }
    }
    if (-not $prev) { return }
    $pk = Get-Key $prev
    if ($pk.Length -lt 2) { return }
    if (Test-OnScreen $pk $screenKey) { return }
    $rest = $prev
    $flushed = $false
    if ($script:flushedTail) {
        $r = Get-AfterFlushed $prev
        if ($null -ne $r) { $rest = $r; $flushed = $true }
    }
    $script:vanish = @{ Key = $pk; Rest = $rest; Flushed = $flushed; Tail = $script:flushedTail; All = $script:flushedAll; FromVanish = $script:flushedFromVanish }
    # 사라진 조각으로 저장한 글의 기억은, 그 뒤 잠깐 고쳐 보이던 조각이 사라져도 그대로 둠(곧 원래 문장이 이어질 수 있음)
    if (-not $script:flushedFromVanish -or $flushed) { $script:flushedTail = ''; $script:flushedAll = ''; $script:flushedFromVanish = $false }
}

$pending = ''       # 아직 말하는 중인 조각
$held = ''          # 방금 끝난 문장(고쳐질 수 있어 한 박자 보류)
$heldKey = ''
$heldTicks = 0
$element = $null
$waiting = $false
$script:recording = $false
$script:idle = $true
$script:sessionCount = 0
$script:worstCode = 0
$script:loopErrors = 0
$script:errRun = 0
$script:simEnd = $false
$OutDir = Split-Path -Parent $OutFile
$explicitOut = $PSBoundParameters.ContainsKey('OutFile')
$startTime = Get-Date

$sync = [hashtable]::Synchronized(@{})
$sync.State = 'idle'          # idle(대기) / recording(받아쓰는 중) / paused(잠시 중지, 같은 파일에 이어 씀)
$sync.PauseRequested = $false
$sync.ResumeRequested = $false
$script:paused = $false
$script:lastChangeAt = Get-Date
$script:lastText = ''
$sync.StartRequested = $false
$sync.CapRestart = $false
# 보기 화면 [편집 모드]에서 고친 문장: 보기 화면 쪽이 요청을 쌓고, 받아쓰기 쪽(이 창)이 차례로 파일에 반영
#   (받아쓰는 파일에 새 문장을 덧붙이는 것과 같은 곳에서 처리하므로 둘이 부딪치지 않음)
$sync.EditQueue = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
$sync.EditResults = [hashtable]::Synchronized(@{})
$sync.StopRequested = $false
$sync.QuitRequested = $false
# 보기 화면(브라우저)을 닫으면 프로그램도 끝냄: 보기 화면이 닫힐 때 '/api/bye'를 보내고,
# 그 뒤 $ByeGraceSec 동안 어떤 보기 화면도 다시 연결하지 않을 때만 끝냄 (새로 고침·[전체화면 초기화]는 곧 다시 연결되므로 끝나지 않음)
$ByeGraceSec = 20
$sync.Attention = 0
$sync.ByeAt = [datetime]::MinValue
$sync.LastSeen = [datetime]::MinValue
$script:lastLoopAt = Get-Date
$sync.Quit = $false
$sync.OutFile = ''
$sync.StartedAt = ''
$sync.LastResult = $null
$sync.Errors = 0
$sync.Worst = 0
$sync.Live = ''
$sync.Speaking = ''
$sync.PlaceRect = $null
$sync.PlaceSeq = 0
$sync.PlaceResult = ''
$script:placeSeqDone = -1
$script:lastPlaced = $null
$script:placedPid = 0
$script:placeCheck = 0
$script:elemCheck = 0
$script:elementPid = 0
$script:sameReads = 0
$script:lastRaw = $null
$script:placeTries = 0
$sync.Cap = ''               # 자막 창 상태: '' 정상, waiting 준비 안 됨, english 한국어가 아닌 듯
$script:capTicks = 0
$script:latinRun = 0
$sync.Dir = $OutDir
$sync.RosterFile = $RosterFile
$sync.KeywordFile = $KeywordFile
$sync.HtmlPath = (Join-Path $ScriptDir '받아쓰기보기.html')

# 자막 창 글자 읽기 (-Peek: 점검용 시험 화면을 넘기지 않고 지금 화면만 봄)
function Read-Screen([switch]$Peek) {
    if ($SimLines) {
        if ($Peek) { if ($script:simIdx -gt 0) { return $SimLines[$script:simIdx - 1] }; return '' }
        if ($script:simIdx -ge $SimLines.Count) {
            if ($WaitStart -and $SimLines.Count -gt 0) { return $SimLines[$SimLines.Count - 1] }
            $script:simEnd = $true; return $null
        }
        $t = $SimLines[$script:simIdx]; $script:simIdx++; $script:element = 1
        return $t
    }
    try {
        # 자막 창을 닫았다 다시 켜면 예전 글자 칸은 빈 글만 돌려주므로, 창(프로세스)이 바뀌었는지 살핌
        if ($script:element) {
            $script:elemCheck++
            if ($script:elemCheck % 3 -eq 0) {
                $p = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Where-Object { $_.Id -eq $script:elementPid }
                if (-not $p) { $script:element = $null; $script:sameReads = 0 }
            }
        }
        if (-not $script:element) { $script:element = Get-CaptionElement }
        if ($script:element) {
            $t = $script:element.Current.Name
            # 글이 오래 그대로면(같은 창 안에서 글자 칸이 새로 만들어진 경우) 글자 칸을 다시 찾아봄
            if ($t -eq $script:lastRaw) { $script:sameReads++ } else { $script:sameReads = 0; $script:lastRaw = $t }
            if ($script:sameReads -ge 8) {
                $script:sameReads = 0
                $e2 = Get-CaptionElement
                if ($e2) { $script:element = $e2; $t = $e2.Current.Name; $script:lastRaw = $t }
                else { $script:element = $null; return $null }
            }
            return $t
        }
    } catch {
        $script:element = $null
    }
    return $null
}

function Format-Caption([string]$text) {
    $text = ($text -replace '\s+', ' ').Trim()
    return ($text -replace '(\d)\.\s+(\d)', '$1.$2')      # 1. 7 → 1.7 (소수점이 문장 끝으로 오인되지 않게)
}

function Split-Caption([string]$text) {
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($p in [regex]::Split($text, '(?<=[.?!])\s+')) {
        $p = $p.Trim()
        if ((Get-Key $p).Length -gt 0) { $parts.Add($p) }
    }
    return ,$parts
}

# 시작 버튼을 누른 순간 자막 창에 이미 떠 있던 글(지난 방송 자막 등)은 저장하지 않고 건너뜀
function Set-Baseline([string]$text) {
    if ([string]::IsNullOrWhiteSpace($text)) { return }
    $text = Format-Caption $text
    $parts = Split-Caption $text
    if ($parts.Count -eq 0) { return }
    $last = ''
    if ($text -notmatch '[.?!]$') { $last = $parts[$parts.Count - 1]; $parts.RemoveAt($parts.Count - 1) }
    foreach ($p in $parts) { $writtenKeys.Add((Get-Key $p)) }
    $lk = Get-Key $last
    if ($lk.Length -ge 8) {
        # 말하는 중이던 조각은 '이미 저장한 앞부분'처럼 다뤄, 이어지는 뒷부분만 저장
        $script:flushedTail = $lk.Substring([Math]::Max(0, $lk.Length - 20))
        $script:flushedAll = $lk
        $script:pending = $last
    }
    $tk = (Get-Key $text).Length
    if ($tk -gt $script:screenKeyMax) { $script:screenKeyMax = $tk }
}

# 이 창에서 Enter 키를 눌렀는지 (보기 화면이 안 열릴 때 시작용)
function Test-EnterKey {
    try {
        $hit = $false
        while ([Console]::KeyAvailable) { $k = [Console]::ReadKey($true); if ($k.Key -eq 'Enter') { $hit = $true } }
        return $hit
    } catch { return $false }
}

# 새 파일 이름: 날짜_01_자동저장노트.txt, 같은 날 다시 시작하면 02, 03 …
function Get-NextOutFile {
    $d = (Get-Date).ToString('yyyyMMdd')
    $max = 0
    foreach ($f in @(Get-ChildItem -LiteralPath $OutDir -Filter ($d + '_*_자동저장노트.txt') -File -ErrorAction SilentlyContinue)) {
        $m = [regex]::Match($f.Name, '^' + $d + '_(\d{2,3})_자동저장노트\.txt$')
        if ($m.Success) { $n = [int]$m.Groups[1].Value; if ($n -gt $max) { $max = $n } }
    }
    return (Join-Path $OutDir ("{0}_{1:00}_자동저장노트.txt" -f $d, ($max + 1)))
}

# 라이브 캡션 창이 떠 있는지 (자막 글자 칸은 첫 자막이 나와야 생기므로 창 자체로 판단)
function Test-CaptionsWindow {
    $proc = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $proc) { return $false }
    try {
        $pidCond = New-Object System.Windows.Automation.PropertyCondition($AE::ProcessIdProperty, $proc.Id)
        return [bool]($AE::RootElement.FindFirst([System.Windows.Automation.TreeScope]::Children, $pidCond))
    } catch { return $true }
}

# 프로그램을 끝낼 때 라이브 캡션 창도 닫음
function Close-LiveCaptions {
    foreach ($p in @(Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue)) {
        try {
            [void]$p.CloseMainWindow()
            if (-not $p.WaitForExit(2000)) { $p.Kill() }
            Write-Host "라이브 캡션 창을 닫았습니다."
        } catch { }
    }
}

# [전체화면 초기화]: 라이브 캡션 창에 남은 지난 자막(다른 영상 소리 등)은 지울 방법이 없어, 창을 닫았다 다시 켬
# 다시 켜진 창은 지난번 맞춘 자리로 저절로 옮겨짐(Update-CaptionsPlace)
function Restart-LiveCaptions {
    if ($SimLines) { return }
    if (-not (Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue)) { return }
    Close-LiveCaptions
    Start-Sleep -Milliseconds 700
    $script:element = $null; $script:elementPid = 0; $script:lastRaw = $null; $script:sameReads = 0
    Start-LiveCaptions
    Write-Host "[전체화면 초기화] 자막 창을 다시 켜서 지난 자막을 지웠습니다."
}

# 라이브 캡션 창을 보기 화면의 '실시간 자막' 칸 위치·크기로 옮김 (실패해도 받아쓰기에는 영향 없음)
$script:winApi = $false
function Initialize-WinApi {
    if ($script:winApi) { return $true }
    try {
        Add-Type -ErrorAction Stop -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class CapWin {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
    [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
    public static IntPtr DpiOn() { try { return SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch { return IntPtr.Zero; } }
    public static void DpiOff(IntPtr old) { try { if (old != IntPtr.Zero) SetThreadDpiAwarenessContext(old); } catch { } }
}
"@
        $script:winApi = $true
    } catch { $script:winApi = $false }
    return $script:winApi
}
function Move-CaptionsWindow($rc) {
    $proc = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero } | Select-Object -First 1
    if (-not $proc) { return 'wait' }
    if (-not (Initialize-WinApi)) { return 'fail' }
    $h = $proc.MainWindowHandle
    $old = [CapWin]::DpiOn()
    try {
        if ([CapWin]::IsIconic($h)) { [void][CapWin]::ShowWindow($h, 9) }
        # 0x14 = 순서·초점은 그대로 두고 위치와 크기만 바꿈
        if (-not [CapWin]::SetWindowPos($h, [IntPtr]::Zero, [int]$rc.x, [int]$rc.y, [int]$rc.w, [int]$rc.h, 0x14)) { return 'fail' }
        Start-Sleep -Milliseconds 300
        $r = New-Object CapWin+RECT
        [void][CapWin]::GetWindowRect($h, [ref]$r)
        # 위쪽·아래쪽 고정(도킹) 상태면 자막 창이 제자리로 돌아감
        if ([Math]::Abs($r.Left - [int]$rc.x) -gt 40 -or [Math]::Abs($r.Top - [int]$rc.y) -gt 40) { return 'docked' }
        return 'ok'
    } catch { return 'fail' }
    finally { [CapWin]::DpiOff($old) }
}
# 보기 화면에서 위치를 보내오면 처리 (자막 창이 아직 없으면 1분 동안 다시 시도)
function Update-CaptionsPlace {
    # 자막 창이 새로 켜지면(닫았다 다시 켠 경우) 지난번 맞춘 자리로 다시 옮김
    if (-not $SimLines -and $script:lastPlaced -and -not $sync.PlaceRect) {
        $script:placeCheck++
        if ($script:placeCheck % 3 -eq 0) {
            $lp = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero } | Select-Object -First 1
            if ($lp -and $lp.Id -ne $script:placedPid) {
                $sync.PlaceRect = $script:lastPlaced; $sync.PlaceSeq = [int]$sync.PlaceSeq + 1
            }
        }
    }
    if (-not $sync.PlaceRect) { return }
    if ($SimLines) { $sync.PlaceResult = 'ok'; $sync.PlaceRect = $null; return }
    if ($sync.PlaceSeq -ne $script:placeSeqDone) { $script:placeSeqDone = $sync.PlaceSeq; $script:placeTries = 0 }
    $script:placeTries++
    if ($script:placeTries -gt 1 -and ($script:placeTries % 3) -ne 0) { return }
    $res = 'fail'
    $rect = $sync.PlaceRect
    try { $res = Move-CaptionsWindow $rect } catch { }
    if ($res -eq 'ok' -or $res -eq 'docked') {
        $script:lastPlaced = $rect
        $lp = Get-Process -Name LiveCaptions -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero } | Select-Object -First 1
        if ($lp) { $script:placedPid = $lp.Id }
    }
    $sync.PlaceResult = $res
    if ($res -ne 'wait' -or $script:placeTries -ge 180) { $sync.PlaceRect = $null }
}
# 보기 화면 '실시간 자막' 칸에 보여 줄 지금 자막 (끝부분만)
function Set-LiveText([string]$t) {
    if ($null -eq $t) { $t = '' }
    $t = ($t -replace '\s+', ' ').Trim()
    if ($t.Length -gt 220) { $t = '…' + $t.Substring($t.Length - 220) }
    $sync.Live = $t
}

# 지금까지 화면에 걸려 있던 문장까지 저장 (중지·종료 때)
function Save-Remaining {
    if ($script:vanish) { Write-Vanished $script:vanish; $script:vanish = $null }
    foreach ($x in @($script:held, $script:pending)) {
        if (-not $x) { continue }
        $k = Get-Key $x
        if ($k.Length -eq 0) { continue }
        $tailCount = [Math]::Min(5, $writtenKeys.Count)
        $tail = @()
        if ($tailCount -gt 0) { $tail = @($writtenKeys.GetRange($writtenKeys.Count - $tailCount, $tailCount)) }
        if (-not (Test-SimilarToAny $k $tail)) { Write-New $x }
    }
    $script:pending = ''; $script:held = ''; $script:heldKey = ''; $script:heldTicks = 0
    $script:flushedTail = ''; $script:flushedAll = ''; $script:flushedFromVanish = $false
}

# 받아쓰기 중지: 같은 파일을 열어 둔 채 저장만 멈춤
function Suspend-Session {
    Save-Remaining
    $stamp = Get-Stamp
    Close-Member $stamp
    Add-Out ("════════ 받아쓰기 중지 [{0}] ════════" -f $stamp) 'Sep' -Index
    Add-Out '' 'Plain'
    [void](Save-Unsaved)
    $script:paused = $true
    $sync.PauseRequested = $false
    $sync.State = 'paused'
    Write-Host "받아쓰기를 잠시 멈췄습니다. 보기 화면의 [▶ 받아쓰기 재개]를 누르면 같은 파일에 이어서 씁니다." -ForegroundColor Green
    Set-Title
}

# 받아쓰기 재개: 멈춘 동안 화면에 지나간 자막은 건너뛰고 같은 파일에 이어 씀
function Resume-Session {
    Add-Out ("════════ 받아쓰기 다시 시작 [{0}] ════════" -f (Get-Stamp)) 'Sep' -Index
    [void](Save-Unsaved)
    $script:vanish = $null
    Set-Baseline (Read-Screen -Peek)
    $script:paused = $false
    $script:lastChangeAt = Get-Date
    $sync.ResumeRequested = $false
    $sync.State = 'recording'
    Write-Host "받아쓰기를 다시 시작했습니다: $OutFile" -ForegroundColor Green
    Set-Title
}

# 받아쓰기 시작: 새 파일 이름을 정하고 처음부터 저장
function Start-Session {
    $script:sessionCount++
    if ($script:sessionCount -gt 1 -or -not $explicitOut) {
        $script:OutFile = Get-NextOutFile
    }
    $writtenKeys.Clear(); $unsaved.Clear(); $unsavedIndex.Clear()
    $script:pending = ''; $script:held = ''; $script:heldKey = ''; $script:heldTicks = 0
    $script:flushedTail = ''; $script:flushedAll = ''; $script:vanish = $null; $script:flushedFromVanish = $false
    $script:current = $null; $script:currentHeard = ''; $script:currentStart = ''; $script:lastPage = ''
    $script:savedCount = 0; $script:writeWarned = $false; $script:indexWarned = $false
    $script:startTime = Get-Date
    $script:latinRun = 0; $script:lastChangeAt = Get-Date; $script:paused = $false
    $sync.PauseRequested = $false; $sync.ResumeRequested = $false
    try {
        Initialize-OutFile
        Write-Headers $script:startTime
    } catch {
        Write-Host "[오류] 저장 파일을 만들지 못했습니다: $OutFile" -ForegroundColor Red
        Write-Host "       원인: $($_.Exception.Message)" -ForegroundColor Red
        $sync.LastResult = @{ file = [System.IO.Path]::GetFileName($OutFile); code = 2; count = 0; at = (Get-Date).ToString('HH:mm'); msg = '저장 파일을 만들지 못했습니다' }
        if ($script:worstCode -lt 2) { $script:worstCode = 2 }
        $sync.Worst = $script:worstCode
        return $false
    }
    Update-SettingsIfChanged
    Write-Host ("`n━━━━━━━━ 받아쓰기 시작 ({0:HH:mm:ss}) ━━━━━━━━" -f $script:startTime) -ForegroundColor Green
    Write-Host "저장 파일: $OutFile"
    Write-Host "목차 파일: $IndexFile"
    Show-Settings
    Write-Host "보기 화면의 [종료하고 저장] 또는 Ctrl+C 로 끝냅니다.`n"
    Set-Baseline (Read-Screen -Peek)
    $script:recording = $true; $script:idle = $false
    $sync.OutFile = $OutFile
    $sync.StartedAt = $script:startTime.ToString('HH:mm:ss')
    $sync.StopRequested = $false
    $sync.State = 'recording'
    Set-Title
    return $true
}

# 받아쓰기 종료: 남은 문장까지 저장하고 대기 상태로
function Stop-Session {
    Save-Remaining
    Close-Member (Get-Stamp)
    $code = Complete-Save
    $msg = '정상 저장'
    if ($code -eq 1) { $msg = '확인 필요: 일부 내용을 _복구.txt 파일에 따로 저장했습니다' }
    elseif ($code -ge 2) { $msg = '저장 실패: 검은 창에 보이는 내용을 복사해 두세요' }
    $sync.LastResult = @{ file = [System.IO.Path]::GetFileName($OutFile); code = $code; count = $script:savedCount; at = (Get-Date).ToString('HH:mm'); msg = $msg }
    if ($code -gt $script:worstCode) { $script:worstCode = $code }
    $sync.Worst = $script:worstCode
    $unsaved.Clear(); $unsavedIndex.Clear()
    $script:pending = ''; $script:held = ''; $script:heldKey = ''; $script:heldTicks = 0
    $script:recording = $false; $script:idle = $true; $script:paused = $false
    $sync.StopRequested = $false; $sync.PauseRequested = $false; $sync.ResumeRequested = $false
    if ($sync.Cap -ne 'waiting') { $sync.Cap = '' }
    $sync.State = 'idle'
    [void](Test-EnterKey)
    Set-Title
    return $code
}

# ───────────────────────── 보기 화면 (내 PC 전용 주소) ─────────────────────────
# 받아쓰기보기.html을 http://127.0.0.1:포트 로 띄워, 폴더를 고르지 않아도 저장 중인 파일이 바로 보이게 함.
# 127.0.0.1(내 PC 안)에만 열리므로 다른 PC에서는 접속할 수 없음. 화면 처리는 별도 작업 공간에서 돌아
# 브라우저가 느리거나 닫혀도 받아쓰기 저장에는 영향이 없음.
# 보기 화면의 [받아쓰기 프로그램 다시 켜기] 버튼용 주소(sjcaption://)를 이 PC 사용자 범위에만 등록 (관리자 권한 불필요)
# 주소 뒤에 붙은 글은 쓰지 않고, 언제나 이 폴더의 실행 파일(Live Notes 실행.bat)만 실행함
function Register-StartLink {
    if ($SimLines -or $NoViewer) { return $false }
    try {
        $bat = Join-Path (Split-Path -Parent $ScriptDir) 'Live Notes 실행.bat'
        if (-not (Test-Path -LiteralPath $bat)) { $bat = Join-Path (Split-Path -Parent $ScriptDir) '받아쓰기_실행파일.bat' }   # 예전 이름
        if (-not (Test-Path -LiteralPath $bat)) { $bat = Join-Path (Split-Path -Parent $ScriptDir) '자막저장_실행.bat' }   # 예전 이름
        if (-not (Test-Path -LiteralPath $bat)) { return $false }
        $k = 'HKCU:\Software\Classes\sjcaption'
        $cmd = '"' + $env:ComSpec + '" /c ""' + $bat + '" /fromviewer"'
        $now = $null
        try { $now = (Get-Item -LiteralPath "$k\shell\open\command" -ErrorAction Stop).GetValue('') } catch { }
        if ($now -ne $cmd) {
            New-Item -Path "$k\shell\open\command" -Force -ErrorAction Stop | Out-Null
            Set-Item -LiteralPath $k -Value 'URL:Live Notes 다시 켜기' -ErrorAction Stop
            New-ItemProperty -LiteralPath $k -Name 'URL Protocol' -Value '' -PropertyType String -Force -ErrorAction Stop | Out-Null
            Set-Item -LiteralPath "$k\shell\open\command" -Value $cmd -ErrorAction Stop
        }
        return $true
    } catch { return $false }
}
# 보기 화면이 뜨면 검은 실행 창은 작업 표시줄로 내려 둠 (실수로 닫는 일을 줄임). 끝날 때 문제가 있으면 다시 띄움
function Set-ConsoleWindow([int]$cmd) {
    if ($SimLines) { return }
    try { if (Initialize-WinApi) { $h = [CapWin]::GetConsoleWindow(); if ($h -ne [IntPtr]::Zero) { [void][CapWin]::ShowWindow($h, $cmd) } } } catch { }
}

$viewerUrl = $null
$listener = $null
$serverPs = $null

if (-not $NoViewer -and (Test-Path -LiteralPath $sync.HtmlPath)) {
    for ($port = $ViewerPort; $port -lt $ViewerPort + 20; $port++) {
        try {
            $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
            $listener.Start()
            break
        } catch { $listener = $null }
    }
    if ($listener) {
        $sync.Listener = $listener
        $sync.Port = $port
        $serverScript = {
            param($sync)
            $utf8 = New-Object System.Text.UTF8Encoding($false)
            $utf8Bom = New-Object System.Text.UTF8Encoding($true)

            function Send-Response($stream, [int]$code, [string]$ctype, [byte[]]$body, [hashtable]$extra) {
                $reason = @{ 200 = 'OK'; 204 = 'No Content'; 400 = 'Bad Request'; 403 = 'Forbidden'; 404 = 'Not Found'; 500 = 'Error' }[$code]
                $h = "HTTP/1.1 $code $reason`r`nContent-Type: $ctype`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n"
                if ($extra) { foreach ($k in $extra.Keys) { $h += "${k}: $($extra[$k])`r`n" } }
                $h += "`r`n"
                $hb = [System.Text.Encoding]::ASCII.GetBytes($h)
                $stream.Write($hb, 0, $hb.Length)
                if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
                $stream.Flush()
            }
            function Send-Json($stream, $obj) {
                $json = $obj | ConvertTo-Json -Compress -Depth 4
                Send-Response $stream 200 'application/json; charset=utf-8' ($utf8.GetBytes($json)) $null
            }
            function Read-Shared([string]$path) {
                $fs = [System.IO.File]::Open($path, 'Open', 'Read', 'ReadWrite, Delete')
                try {
                    $buf = New-Object byte[] $fs.Length
                    $n = 0
                    while ($n -lt $buf.Length) { $r = $fs.Read($buf, $n, $buf.Length - $n); if ($r -le 0) { break }; $n += $r }
                    if ($n -lt $buf.Length) { $b2 = New-Object byte[] $n; [Array]::Copy($buf, $b2, $n); return ,$b2 }
                    return ,$buf
                } finally { $fs.Dispose() }
            }
            function Get-Sig([string]$path) {
                $fi = New-Object System.IO.FileInfo($path)
                if (-not $fi.Exists) { return 'none' }
                return ("{0}:{1}" -f $fi.Length, $fi.LastWriteTimeUtc.Ticks)
            }
            function Test-CaptionName([string]$n) {
                if (-not $n) { return $false }
                if ($sync.OutFile -and $n -eq [System.IO.Path]::GetFileName($sync.OutFile)) { return $true }
                return ($n -match '\.txt$' -and $n.Contains('자동저장노트') -and $n -notmatch '_목차|_복구|_즐겨찾기' -and $n -notmatch '[\\/:*?"<>|]' -and -not $n.Contains('..'))
            }
            function Get-Query([string]$q) {
                $r = @{}
                foreach ($p in ($q -split '&')) {
                    if (-not $p) { continue }
                    $kv = $p -split '=', 2
                    $v = ''; if ($kv.Count -gt 1) { $v = [System.Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) }
                    $r[[System.Uri]::UnescapeDataString($kv[0])] = $v
                }
                return $r
            }

            function Invoke-Client($client) {
                $client.ReceiveTimeout = 3000
                $client.SendTimeout = 3000
                $stream = $client.GetStream()
                try {
                    # 요청 머리 읽기
                    $buf = New-Object byte[] 65536
                    $len = 0; $headEnd = -1
                    while ($headEnd -lt 0 -and $len -lt $buf.Length) {
                        $r = $stream.Read($buf, $len, $buf.Length - $len)
                        if ($r -le 0) { return }
                        $len += $r
                        $txt = [System.Text.Encoding]::ASCII.GetString($buf, 0, $len)
                        $headEnd = $txt.IndexOf("`r`n`r`n")
                    }
                    if ($headEnd -lt 0) { return }
                    $head = $utf8.GetString($buf, 0, $headEnd)
                    $lines = $head -split "`r`n"
                    $first = $lines[0] -split ' '
                    if ($first.Count -lt 2) { return }
                    $method = $first[0]; $target = $first[1]
                    $hdr = @{}
                    foreach ($l in $lines[1..($lines.Count - 1)]) { $i = $l.IndexOf(':'); if ($i -gt 0) { $hdr[$l.Substring(0, $i).Trim().ToLower()] = $l.Substring($i + 1).Trim() } }
                    # 내 PC 주소로 들어온 요청만 받음 (다른 사이트를 거친 접근 차단)
                    $okHost = @("127.0.0.1:$($sync.Port)", "localhost:$($sync.Port)")
                    if ($okHost -notcontains $hdr['host']) { Send-Response $stream 403 'text/plain' ($utf8.GetBytes('forbidden')) $null; return }
                    $body = ''
                    if ($method -eq 'POST') {
                        if ($hdr['x-caption'] -ne '1') { Send-Response $stream 403 'text/plain' ($utf8.GetBytes('forbidden')) $null; return }
                        $cl = 0; [void][int]::TryParse([string]$hdr['content-length'], [ref]$cl)
                        if ($cl -gt 1048576) { Send-Response $stream 400 'text/plain' ($utf8.GetBytes('too large')) $null; return }
                        $have = $len - ($headEnd + 4)
                        $bb = New-Object byte[] $cl
                        if ($have -gt 0) { [Array]::Copy($buf, $headEnd + 4, $bb, 0, [Math]::Min($have, $cl)) }
                        $got = [Math]::Min($have, $cl)
                        while ($got -lt $cl) { $r = $stream.Read($bb, $got, $cl - $got); if ($r -le 0) { break }; $got += $r }
                        $body = $utf8.GetString($bb, 0, $got)
                    }
                    $path = $target; $query = ''
                    $qi = $target.IndexOf('?'); if ($qi -ge 0) { $path = $target.Substring(0, $qi); $query = $target.Substring($qi + 1) }
                    $q = Get-Query $query

                    if ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) {
                        Send-Response $stream 200 'text/html; charset=utf-8' (Read-Shared $sync.HtmlPath) $null; return
                    }
                    if ($method -eq 'GET' -and $path -eq '/api/status') {
                        $sync.LastSeen = Get-Date
                        $st = @{ ok = $true; app = 'livecaptions'; state = [string]$sync.State; file = ''; size = 0; ageSec = 0; startedAt = [string]$sync.StartedAt; last = $sync.LastResult; quitting = [bool]$sync.QuitRequested; worst = [int]$sync.Worst; errors = [int]$sync.Errors; cap = [string]$sync.Cap; attn = [int]$sync.Attention; startLink = [bool]$sync.StartLink; live = [string]$sync.Live; speak = $(if ($sync.State -eq 'recording') { [string]$sync.Speaking } else { '' }); place = [string]$sync.PlaceResult }
                        if (($sync.State -eq 'recording' -or $sync.State -eq 'paused') -and $sync.OutFile) {
                            $fi = New-Object System.IO.FileInfo($sync.OutFile)
                            $st.file = $fi.Name
                            if ($fi.Exists) { $st.size = [long]$fi.Length; $st.ageSec = [int]((Get-Date) - $fi.LastWriteTime).TotalSeconds }
                        }
                        Send-Json $stream $st
                        return
                    }
                    if ($method -eq 'GET' -and $path -eq '/api/files') {
                        $list = @()
                        foreach ($f in (Get-ChildItem -LiteralPath $sync.Dir -Filter '*.txt' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
                            if (Test-CaptionName $f.Name) { $list += $f.Name }
                        }
                        $cur = ''; if ($sync.State -ne 'idle' -and $sync.OutFile) { $cur = [System.IO.Path]::GetFileName($sync.OutFile) }
                        Send-Json $stream @{ current = $cur; files = @($list) }
                        return
                    }
                    if ($method -eq 'GET' -and $path -eq '/api/text') {
                        $name = ''
                        if ($sync.OutFile) { $name = [System.IO.Path]::GetFileName($sync.OutFile) }
                        if ($q['name']) { $name = $q['name'] }
                        if (-not (Test-CaptionName $name)) { Send-Response $stream 404 'text/plain' ($utf8.GetBytes('not found')) $null; return }
                        $fp = Join-Path $sync.Dir $name
                        $sig = Get-Sig $fp
                        if ($sig -eq 'none') { Send-Response $stream 404 'text/plain' ($utf8.GetBytes('not found')) $null; return }
                        if ($q['sig'] -eq $sig) { Send-Response $stream 204 'text/plain' (New-Object byte[] 0) @{ 'X-Sig' = $sig }; return }
                        Send-Response $stream 200 'text/plain; charset=utf-8' (Read-Shared $fp) @{ 'X-Sig' = $sig }
                        return
                    }
                    if ($method -eq 'GET' -and $path -eq '/api/settings') {
                        $rs = ''; $ks = ''
                        if (Test-Path -LiteralPath $sync.RosterFile) { $rs = $utf8.GetString((Read-Shared $sync.RosterFile)).TrimStart([char]0xFEFF) }
                        if (Test-Path -LiteralPath $sync.KeywordFile) { $ks = $utf8.GetString((Read-Shared $sync.KeywordFile)).TrimStart([char]0xFEFF) }
                        Send-Json $stream @{ roster = $rs; keywords = $ks; sig = (Get-Sig $sync.RosterFile) + '|' + (Get-Sig $sync.KeywordFile) }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/edit') {
                        # [편집 모드]에서 고친 문장: 받아쓰기 쪽에 넘기고 반영될 때까지 잠깐 기다림
                        $o = $body | ConvertFrom-Json
                        $name = [string]$o.name
                        if (-not (Test-CaptionName $name)) { Send-Json $stream @{ ok = $false; result = 'fail' }; return }
                        $id = [guid]::NewGuid().ToString('N')
                        [void]$sync.EditQueue.Add(@{ Id = $id; Path = (Join-Path $sync.Dir $name); Start = [int]$o.start; Old = @($o.old | ForEach-Object { [string]$_ }); Text = [string]$o.text })
                        $deadline = (Get-Date).AddSeconds(8)
                        while (-not $sync.EditResults.ContainsKey($id) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 100 }
                        $r = 'timeout'
                        if ($sync.EditResults.ContainsKey($id)) { $r = [string]$sync.EditResults[$id]; $sync.EditResults.Remove($id) }
                        Send-Json $stream @{ ok = ($r -eq 'ok'); result = $r }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/settings') {
                        $o = $body | ConvertFrom-Json
                        [System.IO.File]::WriteAllText($sync.RosterFile, [string]$o.roster, $utf8Bom)
                        [System.IO.File]::WriteAllText($sync.KeywordFile, [string]$o.keywords, $utf8Bom)
                        Send-Json $stream @{ ok = $true; sig = (Get-Sig $sync.RosterFile) + '|' + (Get-Sig $sync.KeywordFile) }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/start') {
                        if ($sync.State -eq 'idle') { $sync.StartRequested = $true }
                        Send-Json $stream @{ ok = $true; state = [string]$sync.State }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/pause') {
                        if ($sync.State -eq 'recording') { $sync.PauseRequested = $true }
                        Send-Json $stream @{ ok = $true; state = [string]$sync.State }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/resume') {
                        if ($sync.State -eq 'paused') { $sync.ResumeRequested = $true }
                        Send-Json $stream @{ ok = $true; state = [string]$sync.State }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/stop') {
                        if ($sync.State -eq 'recording' -or $sync.State -eq 'paused') { $sync.StopRequested = $true }
                        Send-Json $stream @{ ok = $true; state = [string]$sync.State }
                        return
                    }
                    if ($path -eq '/api/marks' -or $path -eq '/api/mark') {
                        # 즐겨찾기: 받아쓰기 파일 옆 '날짜_01_자동저장노트_즐겨찾기.txt'에 '[시각] 문장' 한 줄씩 저장
                        $o = $null; if ($method -eq 'POST') { $o = $body | ConvertFrom-Json }
                        $name = [string]$q['name']; if ($o) { $name = [string]$o.name }
                        if (-not (Test-CaptionName $name)) { Send-Response $stream 404 'text/plain' ($utf8.GetBytes('not found')) $null; return }
                        $mf = Join-Path $sync.Dir ([System.IO.Path]::GetFileNameWithoutExtension($name) + '_즐겨찾기.txt')
                        $marks = New-Object System.Collections.ArrayList
                        if (Test-Path -LiteralPath $mf) {
                            foreach ($ln in [System.IO.File]::ReadAllLines($mf, [System.Text.Encoding]::UTF8)) {
                                $mm = [regex]::Match($ln, '^\[([\d:]+)\]\s?(.*)$')
                                if ($mm.Success) { [void]$marks.Add(@{ ts = $mm.Groups[1].Value; text = $mm.Groups[2].Value }) }
                            }
                        }
                        if ($method -eq 'POST') {
                            $ts = [string]$o.ts
                            if ($ts -notmatch '^[\d:]{4,9}$') { Send-Json $stream @{ ok = $false }; return }
                            $keep = New-Object System.Collections.ArrayList
                            foreach ($k in $marks) { if ($k.ts -ne $ts) { [void]$keep.Add($k) } }
                            if ([bool]$o.on) { [void]$keep.Add(@{ ts = $ts; text = (([string]$o.text) -replace '[\r\n]+', ' ') }) }
                            $secOf = { param($t) $v = 0; foreach ($x in ($t -split ':')) { $v = $v * 60 + [int]$x }; $v }
                            $sorted = @($keep | Sort-Object { & $secOf $_.ts })
                            $okW = $false
                            try {
                                if ($sorted.Count -eq 0) { if (Test-Path -LiteralPath $mf) { Remove-Item -LiteralPath $mf -Force } }
                                else { [System.IO.File]::WriteAllLines($mf, [string[]]@($sorted | ForEach-Object { '[' + $_.ts + '] ' + $_.text }), (New-Object System.Text.UTF8Encoding($true))) }
                                $okW = $true
                            } catch { }
                            Send-Json $stream @{ ok = $okW; marks = @($sorted) }
                            return
                        }
                        Send-Json $stream @{ ok = $true; marks = @($marks) }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/openfolder') {
                        # 보기 화면 [📁 폴더 열기]: 저장 폴더(바탕화면 자동저장노트)를 탐색기로 엶
                        $okOpen = $false
                        try { if (Test-Path -LiteralPath $sync.Dir) { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $sync.Dir + '"'); $okOpen = $true } } catch { }
                        Send-Json $stream @{ ok = $okOpen }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/place') {
                        $o = $body | ConvertFrom-Json
                        $x = 0; $y = 0; $w = 0; $h = 0
                        if ([int]::TryParse([string]$o.x, [ref]$x) -and [int]::TryParse([string]$o.y, [ref]$y) -and [int]::TryParse([string]$o.w, [ref]$w) -and [int]::TryParse([string]$o.h, [ref]$h) -and $w -ge 100 -and $h -ge 40 -and $w -le 10000 -and $h -le 4000) {
                            $sync.PlaceResult = 'wait'
                            $sync.PlaceRect = @{ x = $x; y = $y; w = $w; h = $h }
                            $sync.PlaceSeq = [int]$sync.PlaceSeq + 1
                        }
                        Send-Json $stream @{ ok = $true }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/reset') {
                        # 전체화면 초기화: 대기 중일 때 지난 결과 안내를 지우고, 자막 창을 다시 켜 지난 자막도 지움 (저장 파일·설정은 그대로)
                        if ($sync.State -eq 'idle') { $sync.LastResult = $null; $sync.Live = ''; $sync.CapRestart = $true }
                        Send-Json $stream @{ ok = $true; state = [string]$sync.State }
                        return
                    }
                    if ($method -eq 'GET' -and $path -eq '/api/ping') {
                        # 두 번째로 실행했을 때 쓰는 확인: 보기 화면이 열려 있는지 알려 주고, 열린 화면에 '이미 실행 중' 안내를 띄움
                        $alive = ($sync.LastSeen -gt $sync.ByeAt) -and (((Get-Date) - $sync.LastSeen).TotalSeconds -lt 90)
                        if ($q['attention'] -and $alive) { $sync.Attention = [int]$sync.Attention + 1 }
                        Send-Json $stream @{ ok = $true; app = 'livecaptions'; viewer = [bool]$alive }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/bye') {
                        $sync.ByeAt = Get-Date
                        Send-Json $stream @{ ok = $true }
                        return
                    }
                    if ($method -eq 'POST' -and $path -eq '/api/quit') {
                        $sync.QuitRequested = $true
                        Send-Json $stream @{ ok = $true }
                        return
                    }
                    Send-Response $stream 404 'text/plain' ($utf8.GetBytes('not found')) $null
                } catch {
                    try { Send-Response $stream 500 'text/plain' ($utf8.GetBytes('error')) $null } catch { }
                } finally {
                    try { $stream.Dispose() } catch { }
                    try { $client.Close() } catch { }
                }
            }

            while (-not $sync.Quit) {
                try {
                    if (-not $sync.Listener.Pending()) { Start-Sleep -Milliseconds 50; continue }
                    $c = $sync.Listener.AcceptTcpClient()
                    Invoke-Client $c
                } catch { Start-Sleep -Milliseconds 100 }
            }
        }
        try {
            $rs = [runspacefactory]::CreateRunspace()
            $rs.Open()
            $serverPs = [powershell]::Create()
            $serverPs.Runspace = $rs
            [void]$serverPs.AddScript($serverScript).AddArgument($sync)
            [void]$serverPs.BeginInvoke()
            $viewerUrl = "http://127.0.0.1:$port/"
        } catch {
            try { $listener.Stop() } catch { }
            $listener = $null
        }
    }
    if ($viewerUrl) {
        Write-Host "보기 화면: $viewerUrl  (창을 닫았다면 이 주소를 브라우저 주소창에 넣으세요)" -ForegroundColor Cyan
        # 보기 화면의 [다시 켜기]로 켰고 예전과 같은 주소면, 열려 있는 그 화면이 저절로 다시 연결되므로 새 창을 열지 않음
        if (-not $NoBrowser -and -not ($FromViewer -and $port -eq $ViewerPort)) { try { Start-Process $viewerUrl } catch { } }
        $sync.StartLink = Register-StartLink
        Write-Host ""
        Write-Host "  ※ 이 검은 창은 받아쓰기 프로그램입니다. 받아쓰는 동안 닫지 마세요." -ForegroundColor Yellow
        Write-Host "     작업 표시줄로 내려 둡니다. 끝낼 때는 보기 화면의 [프로그램 끝내기]를 누르세요." -ForegroundColor Yellow
        Write-Host ""
        Set-ConsoleWindow 6
    } else {
        Write-Host "보기 화면을 띄우지 못했습니다. 받아쓰기는 그대로 저장됩니다. (받아쓰기보기.html을 직접 열어 [자동저장노트 폴더 연결]로 볼 수 있습니다)" -ForegroundColor DarkYellow
    }
}

function Stop-Viewer {
    $sync.Quit = $true
    if ($listener) { try { $listener.Stop() } catch { } }
}

if (-not $SimLines) {
    Start-LiveCaptions
    Start-Sleep -Seconds 2
}

# 보기 화면이 있으면 [② 새 기록 시작]을 기다리고, 없으면 바로 시작(예전 방식)
$autoStart = (-not $viewerUrl) -or ($SimLines -and -not $WaitStart)
$abort = $false
try {
    if ($autoStart) {
        if (-not (Start-Session)) { $abort = $true }
    } else {
        Write-Host "`n보기 화면에서 유튜브 주소를 넣고 [② 새 기록 시작]을 누르세요." -ForegroundColor Green
        Write-Host "(보기 화면이 안 열리면 이 창을 누른 뒤 Enter 키를 눌러도 시작됩니다.)"
        Write-Host "프로그램을 끝내려면 보기 화면의 [프로그램 끝내기] 또는 이 창에서 Ctrl+C.`n"
        Set-Title
    }
    while (-not $abort) {
      try {
        Start-Sleep -Milliseconds $IntervalMs
        if ($sync.QuitRequested) { Write-Host "`n보기 화면에서 [프로그램 끝내기]를 눌렀습니다."; break }
        # PC 절전 등으로 한참 멈췄다 깨어난 경우에는 닫힘 판단을 다시 기다림
        $nowT = Get-Date
        if (($nowT - $script:lastLoopAt).TotalSeconds -gt 10 -and $sync.ByeAt -ne [datetime]::MinValue) { $sync.ByeAt = $nowT }
        $script:lastLoopAt = $nowT
        if ($sync.ByeAt -ne [datetime]::MinValue -and ($nowT - $sync.ByeAt).TotalSeconds -ge $ByeGraceSec) {
            if ($sync.LastSeen -gt $sync.ByeAt) { $sync.ByeAt = [datetime]::MinValue }   # 다시 연결됨(새로 고침 등)
            else {
                Write-Host "`n보기 화면(브라우저)이 닫혀서 받아쓰기 프로그램을 끝냅니다. 받아쓰던 내용은 저장합니다."
                $sync.QuitRequested = $true
                break
            }
        }
        Update-CaptionsPlace
        if ($sync.EditQueue.Count -gt 0) { Invoke-PendingEdits }

        if (-not $script:recording -or $script:paused) {
            # 대기·중지 중에도 위원 명단을 바꾸면 방금 받아쓴 파일의 이름을 바로잡음
            $script:tick++
            if ($script:tick % 3 -eq 0) { Update-SettingsIfChanged }
        }
        if (-not $script:recording) {
            # 대기 중: 시작 요청만 기다림 (점검용 시험 화면은 계속 흘러감)
            if ($SimLines -and $WaitStart) { Set-LiveText (Read-Screen) }
            elseif (-not $SimLines) {
                if ($script:capTicks % 2 -eq 0) { Set-LiveText (Read-Screen) }
                # 대기 중에도 자막 창이 준비됐는지 가끔 살펴 보기 화면에 알려 줌 (시작을 막지는 않음)
                $script:capTicks++
                if ($script:capTicks % 3 -eq 1) {
                    try {
                        if (Test-CaptionsWindow) { if ($sync.Cap -eq 'waiting') { $sync.Cap = '' } }
                        else { $sync.Cap = 'waiting' }
                    } catch { }
                }
            }
            if ($sync.CapRestart) { $sync.CapRestart = $false; Restart-LiveCaptions }
            $go = $false
            if ($sync.StartRequested) { $sync.StartRequested = $false; $go = $true }
            elseif (Test-EnterKey) { $go = $true }
            if ($go) { [void](Start-Session) }
            continue
        }
        if ($sync.StopRequested) {
            Write-Host "`n보기 화면에서 [종료하고 저장]을 눌렀습니다."
            [void](Stop-Session)
            Write-Host "`n다시 받아쓰려면 보기 화면의 [② 새 기록 시작](또는 이 창에서 Enter)을 누르세요. 새 파일로 저장됩니다." -ForegroundColor Green
            Write-Host "프로그램을 끝내려면 [프로그램 끝내기] 또는 Ctrl+C.`n"
            continue
        }
        if ($script:paused) {
            if ($SimLines -and $WaitStart) { Set-LiveText (Read-Screen) }   # 점검용: 멈춘 동안에도 시험 화면은 흘러감
            elseif (-not $SimLines) { Set-LiveText (Read-Screen) }
            if ($sync.ResumeRequested) { Resume-Session }
            continue
        }
        if ($sync.PauseRequested) { Suspend-Session; continue }

        if ($unsaved.Count -gt 0 -or $unsavedIndex.Count -gt 0) { [void](Save-Unsaved) }
        $script:tick++
        if ($script:tick % 3 -eq 0) { Update-SettingsIfChanged }

        # 보기 화면의 '지금 말하는 중' 줄: 아직 저장 전인 글(보류 중인 문장 + 말하는 중인 조각). 저장에는 쓰지 않음
        $spk = [string]$pending
        if ($spk -and $script:flushedTail) { $r = Get-AfterFlushed $spk; if ($null -ne $r) { $spk = $r } }
        $spk = (([string]$held) + ' ' + $spk).Trim()
        if ($spk.Length -gt 400) { $spk = '…' + $spk.Substring($spk.Length - 400) }
        $sync.Speaking = $spk

        $text = Read-Screen
        if ($script:simEnd) { break }
        Set-LiveText $text
        if (-not $script:element) {
            if (-not $waiting) {
                Write-Host "자막이 나오기를 기다리는 중입니다. (방송 소리가 나오면 저장이 시작됩니다)"
                Write-Host "(라이브 캡션 창이 안 보이면 Windows 로고 키 + Ctrl + L. 처음 쓰는 PC는 자막 창 안내에서 동의 후 한국어 파일을 내려받아 주세요.)"
                $waiting = $true
            }
            # 자막 창은 떠 있는데 글자 칸이 없으면 아직 자막이 나오지 않은 것(준비 완료 상태)일 뿐
            if (-not $SimLines -and -not (Test-CaptionsWindow)) { $sync.Cap = 'waiting' }
            elseif ($sync.Cap -eq 'waiting') { $sync.Cap = '' }
            if (((Get-Date) - $script:lastChangeAt).TotalSeconds -ge 60 -and -not $sync.Cap) { $sync.Cap = 'silent' }
            Start-LiveCaptions
            Start-Sleep -Seconds 3
            continue
        }
        if ($waiting) { Write-Host "라이브 캡션 연결됨. 자막이 나오면 한 문장씩 저장됩니다.`n"; $waiting = $false }
        if ($sync.Cap -eq 'waiting') { $sync.Cap = '' }
        # 받아쓰는 중인데 자막이 1분 넘게 바뀌지 않으면 알려 줌 (소리 꺼짐, 한국어 파일 미설치, 정회 등)
        if ($text -ne $script:lastText) {
            $script:lastText = $text; $script:lastChangeAt = Get-Date
            if ($sync.Cap -eq 'silent') { $sync.Cap = '' }
        } elseif (((Get-Date) - $script:lastChangeAt).TotalSeconds -ge 60 -and -not $sync.Cap) { $sync.Cap = 'silent' }
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        # 자막이 한국어가 아닌 것 같으면(영문만 계속 나옴) 알려 줌. 저장은 그대로 계속함
        $hangul = [regex]::Matches($text, '[가-힣]').Count
        $latin = [regex]::Matches($text, '[A-Za-z]').Count
        if ($hangul -gt 0) {
            $script:latinRun = 0
            if ($sync.Cap -eq 'english') { $sync.Cap = '' }
        } elseif ($latin -ge 15) {
            $script:latinRun++
            if ($script:latinRun -eq 15) {
                $sync.Cap = 'english'
                Write-Host "[안내] 자막이 영어로 나오는 것 같습니다. 자막 창의 설정(톱니바퀴) → 언어 변경에서 한국어를 골라 주세요." -ForegroundColor DarkYellow
            }
        }

        $text = Format-Caption $text
        $tk = (Get-Key $text).Length
        if ($tk -gt $script:screenKeyMax) { $script:screenKeyMax = $tk }
        Save-VanishedPending $pending (Get-Key $text)

        $parts = Split-Caption $text
        if ($parts.Count -eq 0) { continue }
        # 화면 맨 앞 문장이 앞부분이 잘린 채 남은 '이미 저장한 문장의 뒷부분'이면 빼고 봄 (작은 자막 창에서 중복 저장 방지)
        if ($parts.Count -ge 2 -or $text -match '[.?!]$') {
            $p0 = Get-Key $parts[0]
            if ($p0.Length -gt 0) {
                $lo = [Math]::Max(0, $writtenKeys.Count - 8)
                for ($j = $writtenKeys.Count - 1; $j -ge $lo; $j--) {
                    $wk = $writtenKeys[$j]
                    if ($wk.Length -gt $p0.Length -and $wk.EndsWith($p0, [System.StringComparison]::Ordinal)) { $parts.RemoveAt(0); break }
                }
            }
            if ($parts.Count -eq 0) { continue }
        }
        # 마지막 조각이 문장부호로 끝나지 않으면 아직 말하는 중
        $complete = New-Object System.Collections.Generic.List[string]
        $complete.AddRange($parts)
        # '27.'처럼 숫자 뒤 마침표로 끝나면 소수(27.5)가 이어질 수 있으므로 아직 말하는 중으로 봄
        if ($text -match '[.?!]$' -and $text -notmatch '\d\.$') {
            $pending = ''
        } else {
            $pending = $complete[$complete.Count - 1]
            $complete.RemoveAt($complete.Count - 1)
            Save-LongPending $pending
        }
        # 보류 중이던 문장이 확정되기 전에 화면에서 사라졌으면 지금 저장
        if ($held) {
            # 문장 끝부분이 화면에 남아 있으면(앞부분만 밀려난 경우 포함) 아직 사라지지 않은 것
            $hk = Get-Key $held
            # 끝부분 8글자만 보면 '…하도록 하겠습니다'처럼 흔한 끝말이 다른 문장과 겹치므로, 문장 길이의 절반(12~24글자)을 봄
            $tl = [Math]::Min($hk.Length, [Math]::Min(24, [Math]::Max(12, [int]($hk.Length / 2))))
            $seen = (Get-Key $text).Contains($hk.Substring($hk.Length - $tl))
            if (-not $seen) { foreach ($c in $complete) { if (Test-Similar (Get-Key $c) $hk) { $seen = $true; break } } }
            if (-not $seen) {
                $tailCount = [Math]::Min(5, $writtenKeys.Count)
                $tail = @()
                if ($tailCount -gt 0) { $tail = @($writtenKeys.GetRange($writtenKeys.Count - $tailCount, $tailCount)) }
                # 화면에서 앞부분이 잘려 보이던 이미 저장한 문장이면 다시 쓰지 않음
                $dup = (Test-SimilarToAny $hk $tail)
                if (-not $dup) {
                    $lo = [Math]::Max(0, $writtenKeys.Count - 12)
                    for ($j = $writtenKeys.Count - 1; $j -ge $lo; $j--) { if ($writtenKeys[$j].Contains($hk)) { $dup = $true; break } }
                }
                if (-not $dup) { Write-New $held }
                $held = ''; $heldKey = ''; $heldTicks = 0
            }
        }
        if ($complete.Count -eq 0) { continue }

        # 방금 끝난 문장은 자막이 뒤늦게 고칠 수 있으므로 잠깐 보류
        $lastSentence = $complete[$complete.Count - 1]
        $lastKey = Get-Key $lastSentence
        if ($lastKey -eq $heldKey) { $heldTicks++ } else { $heldKey = $lastKey; $heldTicks = 0 }
        if ($heldTicks -lt $HoldTicks) {
            $held = $lastSentence
            $complete.RemoveAt($complete.Count - 1)
        } else {
            $held = ''
        }
        if ($complete.Count -eq 0) { continue }

        $keys = New-Object System.Collections.Generic.List[string]
        foreach ($c in $complete) { $keys.Add((Get-Key $c)) }

        # 이미 저장한 문장이 화면의 어디까지인지 찾기 (최근 저장분부터 거슬러 올라가며 탐색)
        $start = 0
        $missing = @()
        $found = ($writtenKeys.Count -eq 0)
        if (-not $found) {
            $lo = [Math]::Max(0, $writtenKeys.Count - 12)
            for ($j = $writtenKeys.Count - 1; $j -ge $lo -and -not $found; $j--) {
                $wk = $writtenKeys[$j]
                for ($i = $keys.Count - 1; $i -ge 0; $i--) {
                    if ($keys[$i] -ne $wk) { continue }
                    $ctx = ($i -ge 1 -and $j -ge 1 -and $keys[$i - 1] -eq $writtenKeys[$j - 1])
                    if ($ctx -or $wk.Length -ge 10) {
                        $start = $i + 1
                        if ($j + 1 -lt $writtenKeys.Count) {
                            $missing = @($writtenKeys.GetRange($j + 1, $writtenKeys.Count - $j - 1))
                        }
                        $found = $true
                        break
                    }
                }
            }
        }

        if ($found) {
            for ($i = $start; $i -lt $complete.Count; $i++) {
                if ($missing.Count -gt 0 -and (Test-SimilarToAny $keys[$i] $missing)) {
                    $writtenKeys.Add($keys[$i])      # 이미 저장한 문장이 고쳐진 것 → 다시 쓰지 않음
                    continue
                }
                Write-New $complete[$i]
            }
        } else {
            # 기준점을 못 찾은 경우: 최근 저장분과 겹치지 않는 문장만 저장
            $recentCount = [Math]::Min(60, $writtenKeys.Count)
            $recent = @($writtenKeys.GetRange($writtenKeys.Count - $recentCount, $recentCount))
            for ($i = 0; $i -lt $complete.Count; $i++) {
                if (Test-SimilarToAny $keys[$i] $recent) { continue }
                Write-New $complete[$i]
            }
        }
        if ($writtenKeys.Count -gt 200) { $writtenKeys.RemoveRange(0, $writtenKeys.Count - 80) }
        $script:errRun = 0
      } catch {
        # 한 번의 오류로 받아쓰기 전체가 멈추지 않게 함: 오류를 기록하고 다음 차례에 다시 시도
        $script:loopErrors++; $script:errRun++
        $sync.Errors = $script:loopErrors
        if ($script:loopErrors -le 3) { Write-Host ("[오류] 받아쓰는 중 오류가 났습니다. 계속 다시 시도합니다: {0}" -f $_.Exception.Message) -ForegroundColor Red }
        $script:element = $null
        if ($script:errRun -ge 5) { Start-Sleep -Seconds 2 }
      }
    }
}
finally {
    if ($script:recording) { [void](Stop-Session) }
    if ($sync.QuitRequested -and -not $SimLines) { Close-LiveCaptions }
    Stop-Viewer
    try { $mutex.ReleaseMutex() } catch { }
    $mutex.Dispose()
    # 저장 결과에 맞는 종료 코드를 실행 파일(bat)에 알려 줌 (한 번도 시작하지 않았으면 4)
    $exitCode = $script:worstCode
    if ($script:sessionCount -eq 0) { $exitCode = 4 }
    # 보기 화면의 [프로그램 끝내기]로 문제없이 끝냈으면 5: 실행 창(bat)도 바로 닫힘
    # 받아쓰는 중 오류가 있었으면 6: 일부가 빠졌을 수 있음을 실행 창에 알림
    if ($script:loopErrors -gt 0 -and $exitCode -eq 0) { $exitCode = 6 }
    if ($sync.QuitRequested -and $script:worstCode -eq 0 -and $script:loopErrors -eq 0) { $exitCode = 5 }
    if ($exitCode -ne 5) { Set-ConsoleWindow 9 }   # 안내를 볼 수 있게 검은 창을 다시 띄움
    [Environment]::Exit($exitCode)
}
